package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;



/**
 * Represents a button with two textures for normal and pressed states.
 */
public class Button {
    float x;
    float y;
    float w;
    float h;
    boolean isDown;

    Texture textureUp;
    Texture textureDown;
    /**
     * Constructor to initialize the button with position, size, and textures.
     *
     * @param x           The x-coordinate of the button.
     * @param y           The y-coordinate of the button.
     * @param w           The width of the button.
     * @param h           The height of the button.
     * @param textureUp   The texture for the button when not pressed.
     * @param textureDown The texture for the button when pressed.
     */
    public Button(float x, float y, float w, float h, Texture textureUp, Texture textureDown) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.textureUp = textureUp;
        this.textureDown = textureDown;
    }
    /**
     * Updates the button state based on touch input.
     *
     * @param checkTouch Indicates if the screen is being touched.
     * @param touchX     The x-coordinate of the touch.
     * @param touchY     The y-coordinate of the touch.
     * @return True if the button is pressed, false otherwise.
     */
    public boolean update(boolean checkTouch, int touchX, int touchY) {
        if (checkTouch) {
            int h2 = Gdx.graphics.getHeight();
            //Touch coordinates have origin in top-left instead of bottom-left
            if (touchX >= x && touchX <= x + w && h2 - touchY >= y && h2 - touchY <= y + h) {
                isDown = true;
            } else {
                isDown = false;
            }
        }

        return isDown; // 버튼이 눌렸는지 여부를 반환
    }

        public boolean isPressed() {
            // 여기에 실제 입력 처리 로직을 구현합니다.
            // 예를 들어, 특정 영역이 터치되었는지 확인하는 로직 등이 필요할 수 있습니다.
            // 이 예시에서는 단순히 false를 반환합니다. 실제 구현에서는 입력을 확인하는 로직이 필요합니다.
            return false;
        }
    /**
     * Draws the button on the screen.
     *
     * @param batch The SpriteBatch used for drawing.
     */
    public void draw(SpriteBatch batch) {
        if (isDown) {
            batch.draw(textureDown, x, y, w, h);
        } else {
            batch.draw(textureUp, x, y, w, h);
        }
    }
}
