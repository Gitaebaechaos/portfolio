package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public class Obstacle {
    private Texture texture;
    private Rectangle bounds;
    private float speed = 200;
    private float width;
    private float height;

    public Obstacle(Texture texture) {
        this.texture = texture;
        this.width = 180;
        this.height = 180;
        this.bounds = new Rectangle(
                Gdx.graphics.getWidth(),
                (float) Math.random() * (Gdx.graphics.getHeight() - height),
                width,
                height
        );
    }

    public void update(float deltaTime) {
        bounds.x -= speed * deltaTime;
    }

    public void draw(SpriteBatch batch) {
        batch.draw(texture, bounds.x, bounds.y, width, height);
    }

    public boolean isOffScreen() {
        return bounds.x + bounds.width < 0;
    }

    public boolean collidesWith(Player player) {
        return bounds.overlaps(player.getBounds());
    }

    public void dispose() {
        texture.dispose();
    }
}
