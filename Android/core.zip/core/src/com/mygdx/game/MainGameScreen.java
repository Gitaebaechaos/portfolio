package com.mygdx.game;

/**
 Assets used in this game were purchased from Canva.
 * */

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;

import java.util.Iterator;

/**
 * The main game screen where the game is played.
 */
public class MainGameScreen implements Screen {
    private MyGdxGame game;
    private SpriteBatch batch;
    private Texture background;
    private Texture gameoverTexture;
    private Texture restartTexture;
    private Player player;
    private int distance = 0;
    private Texture levelupTexture;
    private float levelupTime = 0; // Time elapsed in level up state



    private Array<Obstacle> obstacles;
    private float spawnTimer;
    private GameState gameState;
    private Title title;
    private OrthographicCamera camera;
    private Viewport viewport;
    private ShapeRenderer shapeRenderer;

    private float backgroundX = 0;
    private float elapsedTime = 0;
    private BitmapFont font;
    private GlyphLayout layout;

    private Music backgroundMusic;
    private Sound jumpSound;

    private static final float RESTART_BUTTON_WIDTH = 300;
    private static final float RESTART_BUTTON_HEIGHT = 100;
    private static final float WALLET_SCALE = 0.5f;
    /**
     * Constructor to initialize the main game screen.
     *
     * @param game The game instance.
     */
    public MainGameScreen(MyGdxGame game) {
        this.game = game;
        batch = new SpriteBatch();
        background = new Texture("images/background1.png");
        gameoverTexture = new Texture("images/gameover.png");
        restartTexture = new Texture("images/restart.png");
        player = new Player();
        camera = new OrthographicCamera();
        viewport = new FitViewport(Gdx.graphics.getWidth(), Gdx.graphics.getHeight(), camera);
        camera.position.set(viewport.getWorldWidth() / 2, viewport.getWorldHeight() / 2, 0);
        camera.update();
        obstacles = new Array<Obstacle>();
        spawnTimer = 0;
        gameState = GameState.pause;
        title = new Title();
        shapeRenderer = new ShapeRenderer();
        font = new BitmapFont();
        font.getData().setScale(6f, 6f);
        layout = new GlyphLayout();
        levelupTexture = new Texture("images/levelup.png"); // levelup.png 파일 로드


        backgroundMusic = Gdx.audio.newMusic(Gdx.files.internal("audio/background.mp3"));
        jumpSound = Gdx.audio.newSound(Gdx.files.internal("audio/jump.mp3"));

        backgroundMusic.setLooping(true);
        backgroundMusic.play();
    }

    @Override
    public void show() {
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(1, 0, 0, 1);
        update(delta);

        camera.update();
        batch.setProjectionMatrix(camera.combined);

        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();

        batch.begin();

        backgroundX -= 100 * delta;

        float currentX = backgroundX;
        while (currentX < screenWidth) {
            batch.draw(background, currentX, 0, background.getWidth(), screenHeight);
            currentX += background.getWidth();
        }

        player.draw(batch);
        for (Obstacle obstacle : obstacles) {
            obstacle.draw(batch);
        }
        title.render(batch);

        font.setColor(Color.WHITE);
        String timeString = String.format("Distance: %d", distance);
        layout.setText(font, timeString);
        font.draw(batch, layout, 10, Gdx.graphics.getHeight() - 10);

        // Show level up image when in level up state
        if (gameState == GameState.levelup) {
            float levelupX = (screenWidth - levelupTexture.getWidth()) / 2;
            float levelupY = (screenHeight - levelupTexture.getHeight()) / 2;
            batch.draw(levelupTexture, levelupX, levelupY);
        }

        if (gameState == GameState.gameover) {
            float gameoverX = (screenWidth - gameoverTexture.getWidth()) / 2;
            float gameoverY = (screenHeight - gameoverTexture.getHeight()) / 2;
            batch.draw(gameoverTexture, gameoverX, gameoverY);

            float restartWidth = RESTART_BUTTON_WIDTH * 2;
            float restartHeight = RESTART_BUTTON_HEIGHT * 2;
            float restartX = (screenWidth - restartWidth) / 2;
            float restartY = gameoverY - restartHeight - 50;
            batch.draw(restartTexture, restartX, restartY, restartWidth, restartHeight);

            // Handle restart button click
            if (Gdx.input.justTouched()) {
                float touchX = Gdx.input.getX();
                float touchY = Gdx.graphics.getHeight() - Gdx.input.getY();

                if (touchX >= restartX && touchX < restartX + restartWidth &&
                        touchY >= restartY && touchY < restartY + restartHeight) {
                    restartGame();
                }
            }
        }

        batch.end();

//        if (player.getBounds() != null) {
//            shapeRenderer.setProjectionMatrix(camera.combined);
//            shapeRenderer.begin(ShapeRenderer.ShapeType.Line);
//            shapeRenderer.setColor(Color.BLUE); // set invisible color
//        shapeRenderer.rect(player.getBounds().x, player.getBounds().y,
//                    player.getBounds().width, player.getBounds().height);
//            shapeRenderer.end();
//        }
    }
    /**
     * Updates the game logic.
     *
     * @param deltaTime The time elapsed since the last frame.
     */
    private void update(float deltaTime) {
        if (gameState == GameState.play) {
            spawnTimer += deltaTime;
            elapsedTime += deltaTime;

            if (spawnTimer > 1) {
                spawnObstacle();
                spawnTimer = 0;
            }
            player.update();
            for (Iterator<Obstacle> iter = obstacles.iterator(); iter.hasNext(); ) {
                Obstacle obstacle = iter.next();
                obstacle.update(deltaTime);
                if (obstacle.isOffScreen()) {
                    iter.remove();
                }
                if (obstacle.collidesWith(player)) {
                    gameState = GameState.gameover;
                }
            }

            // Update the distance based on elapsed time
            distance = (int) elapsedTime;

            // Transition to Stage2 when distance exceeds threshold
            if (distance > 15) {
                gameState = GameState.levelup;
            }

           //Limit player's y position (prevent going above the top of the screen)
            float playerY = player.getY();
            float screenHeight = Gdx.graphics.getHeight();
            float playerHeight = player.getHeight();

            if (playerY + playerHeight > screenHeight) {
                player.setY(screenHeight - playerHeight);
                player.ySpeed = 0; // Set velocity to 0 to stop further upward movement
            }


        }
        if (gameState == GameState.levelup) {
            levelupTime += deltaTime; // levelup 상태에서 경과 시간 업데이트
            if (levelupTime > 2) {
                game.setScreen(new Stage2(game));
            }
        }

        if (Gdx.input.justTouched()) {
            player.moveUp();
            jumpSound.play();
            if (gameState == GameState.pause) {
                gameState = GameState.play;
            } else if (gameState == GameState.gameover) {
                // 게임 오버 시 처리
                // 여기서는 아무 동작도 하지 않고, 그림만 나타냅니다.
            }
        }
    }
    /**
     * Spawns a new obstacle at a random position.
     */
    private void spawnObstacle() {
        Texture[] obstacleTextures = new Texture[]{
                new Texture("images/beer.png"),
                new Texture("images/soju.png"),
                new Texture("images/pizza.png")
        };
        int index = (int) (Math.random() * obstacleTextures.length);
        obstacles.add(new Obstacle(obstacleTextures[index]));
    }
    /**
     * Restarts the game by clearing obstacles and resetting the player.
     */
    private void restartGame() {
        obstacles.clear();
        player.reset();
        gameState = GameState.pause;
        elapsedTime = 0;
        distance = 0;
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
        gameState = GameState.play;
    }

    @Override
    public void hide() {
    }

    @Override
    public void dispose() {
        batch.dispose();
        background.dispose();
        gameoverTexture.dispose();
        restartTexture.dispose();
        player.dispose();
        for (Obstacle obstacle : obstacles) {
            obstacle.dispose();
        }
        title.dispose();
        shapeRenderer.dispose();
        font.dispose();
        backgroundMusic.dispose();
        jumpSound.dispose();
    }
}