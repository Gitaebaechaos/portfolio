package com.mygdx.game;

/**
 *
 * TiledMap implementation sourced from
 * http://www.gamefromscratch.com/post/2014/04/16/LibGDX-Tutorial-11-Tiled-Maps-Part-1-Simple-Orthogonal-Maps.aspx
 * follow link for more details.
 *
 * Coin.png asset used in this game is purchased from Canva.
 * Success.png asset used in this game is purchased from 출저
 * */

import com.badlogic.gdx.Application;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapRenderer;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
/**
 * Represents the second stage of the game.
 */
public class Stage2 implements Screen {
    private MyGdxGame game;
    /**
     * Constructor to initialize the stage with the game instance.
     *
     * @param game The game instance.
     */
    public Stage2(MyGdxGame game) {
        this.game = game;
    }
    /**
     * Represents the possible states of the game.
     */
    public enum GameState { PLAYING, COMPLETE }

    public static final float MOVEMENT_SPEED = 200.0f;
    public static final float GOAL_BOB_HEIGHT = 5.0f;

    GameState gameState = GameState.PLAYING;

    SpriteBatch spriteBatch;
    SpriteBatch uiBatch;
    TiledMap tiledMap;
    TiledMapRenderer tiledMapRenderer;
    OrthographicCamera camera;

    float dt;

    Texture playerTexture;
    Sprite playerSprite;
    Vector2 playerDelta;
    Rectangle playerDeltaRectangle;

    Texture goalTexture;
    Sprite goalSprite;
    Vector2 goalPosition;
    float goalBobSine;

    BitmapFont bmfont;

    Rectangle opacityTrigger = new Rectangle();
    float overheadOpacity = 1f;

    Rectangle tileRectangle;

    Texture buttonSquareTexture;
    Texture buttonSquareDownTexture;
    Texture buttonLongTexture;
    Texture buttonLongDownTexture;

    Button moveLeftButton;
    Button moveRightButton;
    Button moveDownButton;
    Button moveUpButton;
    Texture restartTexture;
    Sprite restartButton;

    float elapsedTime = 0; // 경과 시간을 저장할 변수 추가
    BitmapFont font; // 시간 표시를 위한 폰트
    boolean isCompleted = false; // 목표 지점 도달 여부를 나타내는 플래그 변수

    @Override
    public void show() {
        create();
        font = new BitmapFont();
        font.getData().setScale(5, 5);
    }
    /**
     * Initializes the game screen elements.
     */
    public void create() {
        Gdx.app.setLogLevel(Application.LOG_DEBUG);

        spriteBatch = new SpriteBatch();
        uiBatch = new SpriteBatch();
        tiledMap = new TmxMapLoader().load("maps/MageCity.tmx");
        tiledMapRenderer = new LayerRenderer(tiledMap);

        float w = Gdx.graphics.getWidth();
        float h = Gdx.graphics.getHeight();
        camera = new OrthographicCamera();
        camera.setToOrtho(false, w / h * 250, 250);

        playerTexture = new Texture("images/player.png");
        goalTexture = new Texture("images/coin.png");
        buttonSquareTexture = new Texture("buttonSquare_blue.png");
        buttonSquareDownTexture = new Texture("buttonSquare_beige_pressed.png");
        buttonLongTexture = new Texture("buttonLong_blue.png");
        buttonLongDownTexture = new Texture("buttonLong_beige_pressed.png");
        restartTexture = new Texture("images/success.png");

        restartButton = new Sprite(restartTexture);
        restartButton.setSize(50, 50);
        // 화면 중앙에 위치
        restartButton.setPosition(
                Gdx.graphics.getWidth() / 2f - restartButton.getWidth() / 2f,
                Gdx.graphics.getHeight() / 2f - restartButton.getHeight() / 2f
        );
        restartButton.setSize(1200, 1200);
        restartButton.setPosition(Gdx.graphics.getWidth() /  - 50, Gdx.graphics.getHeight() /  - 50); // 화면 중앙에 위치하도록 조정

        tileRectangle = new Rectangle();
        MapLayer collisionLayer = tiledMap.getLayers().get("Collision");
        TiledMapTileLayer tileLayer = (TiledMapTileLayer) collisionLayer;
        tileRectangle.width = tileLayer.getTileWidth();
        tileRectangle.height = tileLayer.getTileHeight();

        goalSprite = new Sprite(goalTexture);
        goalSprite.setSize(24, 24);
        goalPosition = new Vector2(0, 0);
        goalBobSine = 0.0f;

        bmfont = new BitmapFont(); // BitmapFont 초기화

        playerSprite = new Sprite(playerTexture);
        playerSprite.setSize(24, 24);
        playerDelta = new Vector2();
        playerDeltaRectangle = new Rectangle(0, 0, playerSprite.getWidth(), playerSprite.getHeight());

        float buttonSize = h * 0.1f;
        moveLeftButton = new Button(0.0f, buttonSize, buttonSize, buttonSize, buttonSquareTexture, buttonSquareDownTexture);
        moveRightButton = new Button(buttonSize * 2, buttonSize, buttonSize, buttonSize, buttonSquareTexture, buttonSquareDownTexture);
        moveDownButton = new Button(buttonSize, 0.0f, buttonSize, buttonSize, buttonSquareTexture, buttonSquareDownTexture);
        moveUpButton = new Button(buttonSize, buttonSize * 2, buttonSize, buttonSize, buttonSquareTexture, buttonSquareDownTexture);

        newGame();
    }
    /**
     * Resets the game state to start a new game.
     */
    private void newGame() {
        gameState = GameState.PLAYING;
        camera.position.x = 16;
        camera.position.y = 16;

        dt = 0.0f;

        MapLayer objectLayer = tiledMap.getLayers().get("Objects");

        RectangleMapObject playerObject = (RectangleMapObject) objectLayer.getObjects().get("Player");
        playerSprite.setCenter(playerObject.getRectangle().x, playerObject.getRectangle().y);
        camera.translate(playerSprite.getX(), playerSprite.getY());

        RectangleMapObject goalObject = (RectangleMapObject) objectLayer.getObjects().get("Goal");
        goalPosition.x = goalObject.getRectangle().x;
        goalPosition.y = goalObject.getRectangle().y;
        goalSprite.setPosition(goalPosition.x, goalPosition.y); // 목적지 스프라이트 위치 설정

        RectangleMapObject opacityObject = (RectangleMapObject) objectLayer.getObjects().get("Fadeout");
        opacityTrigger.set(opacityObject.getRectangle());
    }

    @Override
    public void dispose() {
        tiledMap.dispose();
        playerTexture.dispose();
        buttonSquareTexture.dispose();
        buttonSquareDownTexture.dispose();
        buttonLongTexture.dispose();
        buttonLongDownTexture.dispose();
        bmfont.dispose();
        restartTexture.dispose();
    }

    @Override
    public void render(float delta) {
        dt = delta;// Set delta time
        update();// Update game logic
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        camera.update();
        tiledMapRenderer.setView(camera);
        // Draw only non-overhead layers
        TiledMapTileLayer overhead = (TiledMapTileLayer) tiledMap.getLayers().get("Overhead");
        for (MapLayer l : tiledMap.getLayers()) {
            if (!l.isVisible() || l == overhead || !(l instanceof TiledMapTileLayer)) {
                continue;
            }
            tiledMapRenderer.renderTileLayer((TiledMapTileLayer) l);
        }
        // Apply camera to spritebatch and draw player and goal
        spriteBatch.setProjectionMatrix(camera.combined);
        spriteBatch.begin();
        goalSprite.draw(spriteBatch); // Draw goal sprite
        playerSprite.draw(spriteBatch);
        spriteBatch.end();


        uiBatch.begin();
        if (gameState == GameState.PLAYING) {
            font.draw(uiBatch, "Time: " + (int) elapsedTime, 10, Gdx.graphics.getHeight() - 10);
        } else if (gameState == GameState.COMPLETE) {
            font.draw(uiBatch, "Clear Time: " + (int) elapsedTime, Gdx.graphics.getWidth() / 2f - 50, Gdx.graphics.getHeight() / 2f);

            // Handle touch input (switch to stage3 on touch)
            if (Gdx.input.justTouched()) {
                game.setScreen(new stage3(game)); // stage3로 전환
            }
        }
        uiBatch.end();

        // Set overhead layer opacity
        overhead.setOpacity(MathUtils.lerp(0.8f, 1.0f, overheadOpacity));

        // Draw overhead layer
        tiledMapRenderer.renderTileLayer(overhead);

        // Draw UI
        uiBatch.begin();
        switch (gameState) {
            case PLAYING: {
                moveLeftButton.draw(uiBatch);
                moveRightButton.draw(uiBatch);
                moveDownButton.draw(uiBatch);
                moveUpButton.draw(uiBatch);
                bmfont.setColor(1f, 1f, 1f, 1f - overheadOpacity);
                bmfont.draw(uiBatch, "HIDDEN", Gdx.graphics.getWidth() / 2, Gdx.graphics.getHeight() * 5 / 6, 0f, 1, false);
            } break;
            case COMPLETE: {
                restartButton.draw(uiBatch); // 재시작 버튼 그리기

            } break;
        }
        uiBatch.end();


    }
    /**
     * Updates the game logic.
     */
    private void update() {
        if (gameState == GameState.PLAYING) {
            // Calculate time
            elapsedTime += Gdx.graphics.getDeltaTime();
            int moveX = 0;
            int moveY = 0;

            // Check for player movement input
            if (Gdx.input.isKeyJustPressed(Input.Keys.DPAD_LEFT)) {
                moveX -= tileRectangle.width;
            }
            if (Gdx.input.isKeyJustPressed(Input.Keys.DPAD_RIGHT)) {
                moveX += tileRectangle.width;
            }
            if (Gdx.input.isKeyJustPressed(Input.Keys.DPAD_DOWN)) {
                moveY -= tileRectangle.height;
            }
            if (Gdx.input.isKeyJustPressed(Input.Keys.DPAD_UP)) {
                moveY += tileRectangle.height;
            }

            float newX = playerSprite.getX() + moveX;
            float newY = playerSprite.getY() + moveY;

            // Tile coordinates for collision detection
            int tileX = MathUtils.floor(newX / tileRectangle.width);
            int tileY = MathUtils.floor(newY / tileRectangle.height);

            // Check for collision with the Collision layer
            TiledMapTileLayer collisionLayer = (TiledMapTileLayer) tiledMap.getLayers().get("Collision");
            boolean canMove = true;
            if (collisionLayer != null) {
                TiledMapTileLayer.Cell cell = collisionLayer.getCell(tileX, tileY);
                canMove = (cell == null);
            }

            // Move player if no collision
            if (canMove) {
                playerSprite.setPosition(newX, newY);
                camera.position.set(newX, newY, 0);
                camera.update();
            }

            // Check if the player has reached the goal
            if (playerSprite.getBoundingRectangle().overlaps(goalSprite.getBoundingRectangle())) {
                gameState = GameState.COMPLETE;
            }
        } else if (gameState == GameState.COMPLETE) {
            // Restart button click handling
            if (Gdx.input.justTouched()) {
                Vector2 touchPos = new Vector2(Gdx.input.getX(), Gdx.graphics.getHeight() - Gdx.input.getY());
                if (restartButton.getBoundingRectangle().contains(touchPos)) {
                    // swich screen to sgate3 when stage 2 is completed
                    game.setScreen(new stage3(game));

                }
                else {
                    // 여기에 Stage3로 전환하는 코드 추가
                    game.setScreen(new stage3(game)); // game.setScreen() 메소드와 Stage3 생성자는 예시입니다. 실제 구현에 맞게 조정해야 합니다.
                }
            }
        }
    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
    }
}