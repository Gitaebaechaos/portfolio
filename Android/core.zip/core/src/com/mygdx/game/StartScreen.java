package com.mygdx.game;

/**
 Assets used in this game were purchased from Canva.
 * */

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class StartScreen implements Screen {
    private MyGdxGame game;
    private SpriteBatch batch;
    private Texture backgroundImage;
    private Stage stage;
    private Image startButton;
    private BitmapFont font;
    private Texture buttonImage;

    public StartScreen(MyGdxGame game) {
        this.game = game;
        batch = new SpriteBatch();
        backgroundImage = new Texture(Gdx.files.internal("images/whopay.png")); // 배경 이미지 경로
        buttonImage = new Texture(Gdx.files.internal("images/startButton.png")); // 버튼 이미지 경로

        // 스테이지 생성 및 입력 프로세서로 설정
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        // 폰트 생성
        font = new BitmapFont();
        font.getData().setScale(5); // 폰트 크기 조정

        // 버튼 생성
        startButton = new Image(buttonImage);
        startButton.setSize(850, 630); // 버튼 크기 설정
        startButton.setPosition(
                Gdx.graphics.getWidth() / 2f - startButton.getWidth() / 2f,
                Gdx.graphics.getHeight() / 2f - startButton.getHeight() / 2f - 100
        );
        startButton.addListener(new ClickListener() {
            @Override
            public void clicked(com.badlogic.gdx.scenes.scene2d.InputEvent event, float x, float y) {
                Gdx.app.log("StartScreen", "Start button clicked");
                try {
                    game.setScreen(new MainGameScreen(game));
                    Gdx.app.log("StartScreen", "Screen switched to Stage2");
                } catch (Exception e) {
                    Gdx.app.error("StartScreen", "Error switching to Stage2", e);
                }
                dispose();
            }
        });

        // 버튼을 스테이지에 추가
        stage.addActor(startButton);
    }

    @Override
    public void show() {
        Gdx.app.log("StartScreen", "Start screen shown");
    }

    @Override
    public void render(float delta) {
        // 화면 지우기
        ScreenUtils.clear(0, 0, 0, 1);

        // 배경 이미지 그리기
        batch.begin();
        batch.draw(backgroundImage, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        batch.end();

        // 스테이지 그리기 (버튼 포함)
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void dispose() {
        batch.dispose();
        backgroundImage.dispose();
        stage.dispose();
        font.dispose();
    }
}
