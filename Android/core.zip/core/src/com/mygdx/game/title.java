package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.Gdx;

class Title {
    private Texture getReadyTexture;
    private Texture gameOverTexture;
    private float xSize;
    private float ySize;
    private GameState gameState;

    public Title() { // Make sure the constructor is public
        getReadyTexture = new Texture("images/ready.png");
        gameOverTexture = new Texture("images/gameover.png");
    }

    public void render(SpriteBatch batch) {
        if (gameState == GameState.pause) {
            xSize = Gdx.graphics.getWidth() * 0.6f;
            ySize = xSize / getReadyTexture.getWidth() * getReadyTexture.getHeight();
            batch.draw(getReadyTexture, Gdx.graphics.getWidth() * 0.2f, Gdx.graphics.getHeight() * 0.4f, xSize, ySize);
        } else if (gameState == GameState.gameover) {
            xSize = Gdx.graphics.getWidth() * 0.6f;
            ySize = xSize / gameOverTexture.getWidth() * gameOverTexture.getHeight();
            batch.draw(gameOverTexture, Gdx.graphics.getWidth() * 0.2f, Gdx.graphics.getHeight() * 0.4f, xSize, ySize);
        }
    }

    public void dispose() {
        getReadyTexture.dispose();
        gameOverTexture.dispose();
    }

    public void setGameState(GameState gameState) {
        this.gameState = gameState;
    }
}
