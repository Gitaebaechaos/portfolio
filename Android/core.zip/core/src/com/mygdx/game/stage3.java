package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Align;

/**
 Assets used in this game were purchased from 출저
 * */
/**
 * Represents the third stage of the game.
 */
public class stage3 implements Screen {
    private static final int WORLD_WIDTH = 1280;
    private static final int WORLD_HEIGHT = 720;
    private static final float OBSTACLE_MAX_Y = WORLD_HEIGHT * 0.5f;
    private boolean playerStarted = false;

    private Stage stage;
    private Image player, background, background2, background4, gameOverScreen, destination, successScreen;
    private Music bgMusic, pointMusic;
    private Sound jumpSound, collisionSound;
    private float distance = 0;
    private boolean isGameOver = false;
    private Array<Image> obstacles = new Array<>();
    private BitmapFont font;
    private SpriteBatch batch;
    private GlyphLayout layout;

    private float jumpVelocity = 0;
    private final float gravity = -400;
    private final float jumpCooldown = 0.2f;
    private float timeSinceLastJump = 0;
    private float lastObstacleDistance = 0;
    private MyGdxGame game;
    /**
     * Constructor to initialize the stage with the game instance.
     *
     * @param game The game instance.
     */
    public stage3(MyGdxGame game) {
        this.game = game;
        setupStage();
        setupMusicAndSounds();
        setupActors();
        setupUI();
    }
    /**
     * Sets up the stage for the game.
     */
    private void setupStage() {
        stage = new Stage(new FitViewport(WORLD_WIDTH, WORLD_HEIGHT));
        Gdx.input.setInputProcessor(stage);
    }
    /**
     * Sets up the music and sound effects.
     */
    private void setupMusicAndSounds() {
        bgMusic = Gdx.audio.newMusic(Gdx.files.internal("audio/bg_music.mp3"));
        pointMusic = Gdx.audio.newMusic(Gdx.files.internal("audio/pontos.mp3"));
        jumpSound = Gdx.audio.newSound(Gdx.files.internal("audio/pulo.wav"));
        collisionSound = Gdx.audio.newSound(Gdx.files.internal("audio/colisao.wav"));
        bgMusic.setLooping(true);
        bgMusic.play();
    }
    /**
     * Sets up the actors for the game.
     */
    private void setupActors() {
        background = new Image(new Texture("images/background4.png"));
        background2 = new Image(new Texture("images/background4.png"));
        background4 = new Image(new Texture("images/background4.png"));
        player = new Image(new Texture("images/passaro.png"));
        gameOverScreen = new Image(new Texture("images/gameover.png"));
        destination = new Image(new Texture("images/destination.png"));
        successScreen = new Image(new Texture("images/success.png"));
        stage.addActor(background);
        stage.addActor(background2);
        stage.addActor(player);
        stage.addActor(gameOverScreen);
        stage.addActor(destination);
        stage.addActor(successScreen);
        background2.setPosition(background.getWidth(), 0);
        gameOverScreen.setVisible(false);
        destination.setVisible(false);
        successScreen.setVisible(false);
        player.setPosition(100, WORLD_HEIGHT - player.getHeight());
        destination.setPosition(WORLD_WIDTH - 200, WORLD_HEIGHT / 2f);
        successScreen.setPosition(WORLD_WIDTH / 2f - successScreen.getWidth() / 2f, WORLD_HEIGHT / 2f - successScreen.getHeight() / 2f);
    }
    /**
     * Sets up the UI elements.
     */
    private void setupUI() {
        font = new BitmapFont();
        font.getData().setScale(3);
        batch = new SpriteBatch();
        layout = new GlyphLayout();
    }


    @Override
    public void render(float delta) {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // 게임 오버 또는 클리어 상태일 때 터치 입력 처리
        if (isGameOver && Gdx.input.justTouched()) {
            gameOverScreen.setVisible(false);
            successScreen.setVisible(false);
            game.setScreen(new StartScreen(game));
            return; // not render further after screen switch
        }

        // Update game logic if game is in progress or not started
        if (!isGameOver) {
            if (playerStarted) { // Check if the player has started moving
                timeSinceLastJump += delta;
                updateObstacles(delta);
                updatePlayer(delta);
                checkIfPlayerFalls();
                gameClear();
            }
            handleInput(delta); // Handle input always, regardless of player start state
        }
        // Move background and destination
        moveBackgroundAndDestination(delta);

        // Update and draw the stage
        stage.act(delta);
        stage.draw();

        // Render UI elements (distance display)
        batch.begin();
        layout.setText(font, "Distance: " + (int) distance);
        font.draw(batch, layout, 20, Gdx.graphics.getHeight() - 20);
        batch.end();
    }
    /**
     * Handles input from the user.
     *
     * @param delta Time since the last frame.
     */
    private void handleInput(float delta) {
        if (Gdx.input.isTouched()) {
            if (!playerStarted) {
                playerStarted = true; // 플레이어가 움직임을 시작했음을 표시
            }
            if (timeSinceLastJump > jumpCooldown) {
                jumpSound.play();
                jumpVelocity = 300;
                timeSinceLastJump = 0;
            }
        }
    }

    private void updatePlayer(float delta) {
        jumpVelocity += gravity * delta;
        player.moveBy(0, jumpVelocity * delta);
        if (player.getY() + player.getHeight() > WORLD_HEIGHT) {
            player.setY(WORLD_HEIGHT - player.getHeight());
            jumpVelocity = 0;
        }
        if (player.getY() <= 0) {
            player.setY(0);
            jumpVelocity = 300;
        }
    }

    public void updateObstacles(float delta) {
        distance += delta;
        if (distance >= lastObstacleDistance + 3) {
            String textureName = "";
            boolean placeOnTop = false;
            switch ((int) (distance / 3)) {
                case 1: textureName = "images/hurdle_1.png"; placeOnTop = true; break;
                case 2: textureName = "images/hurdle_2.png"; break;
                case 3: textureName = "images/ob_h1re.png"; placeOnTop = true; break;
                case 4: textureName = "images/ob_h1.png"; break;
                case 5: textureName = "images/ob_snmre.png"; placeOnTop = true; break;
                case 6: textureName = "images/ob_snm.png"; break;
                case 7: textureName = "images/ob_tr1re.png"; placeOnTop = true; break;
                case 8: textureName = "images/ob_tr1.png"; break;
                case 9: textureName = "images/ob_tr2re.png"; placeOnTop = true; break;
                case 10: textureName = "images/ob_tr2.png"; break;
                case 11: textureName = "images/ob_tr3re.png"; placeOnTop = true; break;
                case 12: textureName = "images/ob_tr3.png"; break;
                case 13: textureName = "images/ob_tr4re.png"; placeOnTop = true; break;
                case 14: textureName = "images/ob_tr4.png"; break;
                case 15: textureName = "images/ob_tr4re.png"; placeOnTop = true; break;
                case 16: textureName = "images/ob_tr4.png"; break;
                case 17: textureName = "images/ob_tr4re.png"; placeOnTop = true; break;
            }
            if (!textureName.isEmpty()) {
                createFixedObstacle(textureName, placeOnTop);
                lastObstacleDistance = distance;
            }
        }
        checkCollisions();
    }
    /**
     * Creates a fixed obstacle in the game.
     *
     * @param textureName The name of the texture to use for the obstacle.
     * @param placeOnTop Whether to place the obstacle on top of the screen.
     */
    private void createFixedObstacle(String textureName, boolean placeOnTop) {
        Image obstacle = new Image(new Texture(textureName));
        // 장애물의 기본 크기를 설정합니다. 거리에 따라 크기가 달라집니다.
        float scaleFactor = 1.0f + Math.min(0.1f * ((int)distance / 10), 0.5f); // 거리가 증가함에 따라 최대 50%까지 크기 증가
        obstacle.setSize(obstacle.getWidth() * 0.3f * scaleFactor, obstacle.getHeight() * 0.3f * scaleFactor);
        float originalHeight = obstacle.getHeight();
        float obstacleXPosition = WORLD_WIDTH;
        if (!obstacles.isEmpty()) {
            Image lastObstacle = obstacles.peek();
            obstacleXPosition = Math.max(obstacleXPosition, lastObstacle.getX() + lastObstacle.getWidth() + 50);
        }
        float obstacleYPosition = placeOnTop ? WORLD_HEIGHT - obstacle.getHeight() : 0;
        obstacle.setPosition(obstacleXPosition, obstacleYPosition);
        stage.addActor(obstacle);
        obstacles.add(obstacle);

        // 장애물 길이 변경 액션 추가, 높이 변경 양을 100으로 증가
        float heightChangeAmount = 200; // 높이 변경 양을 50에서 100으로 변경
        float heightChangeDuration = 2f; // 높이 변경에 걸리는 시간
        obstacle.addAction(Actions.forever(Actions.sequence(
                Actions.sizeTo(obstacle.getWidth(), originalHeight + heightChangeAmount, heightChangeDuration),
                Actions.sizeTo(obstacle.getWidth(), originalHeight, heightChangeDuration)
        )));

        obstacle.addAction(Actions.sequence(Actions.moveBy(-WORLD_WIDTH - distance * 10, 0, 5), Actions.removeActor()));
    }
    /**
     * Checks for collisions between the player and obstacles.
     */
    private void checkCollisions() {
        for (Image obstacle : obstacles) {
            if (obstacle.getX() < player.getX() + player.getWidth() && obstacle.getX() + obstacle.getWidth() > player.getX() && obstacle.getY() < player.getY() + player.getHeight() && obstacle.getY() + obstacle.getHeight() > player.getY()) {
                gameOver();
                break;
            }
        }
    }

    private void checkIfPlayerFalls() {
        if (player.getY() <= 0) {
            gameOver();
        }
    }
    /**
     * Handles the game over logic.
     */
    public void gameOver() {
        isGameOver = true;
        bgMusic.stop();
        collisionSound.play();
        gameOverScreen.setVisible(true);
        gameOverScreen.setPosition(0, 0); // 좌상단으로 이동
        gameOverScreen.addAction(Actions.moveToAligned(
                WORLD_WIDTH / 2f, WORLD_HEIGHT / 2f, Align.center));
    }
    /**
     * Handles the game clear logic.
     */
    public void gameClear() {
        if (!isGameOver && distance >= 50) {
            isGameOver = true;
            bgMusic.stop();
            pointMusic.play();
            successScreen.setVisible(true);
        }
    }
    /**
     * Moves the background and destination.
     *
     * @param delta Time since the last frame.
     */
    private void moveBackgroundAndDestination(float delta) {
        background.setX(background.getX() - delta * 100);
        background2.setX(background2.getX() - delta * 100);

        if (background.getX() + background.getWidth() <= 0) {
            background.setX(background2.getX() + background2.getWidth());
        }
        if (background2.getX() + background2.getWidth() <= 0) {
            background2.setX(background.getX() + background.getWidth());
        }

        if (!isGameOver) {
            destination.setX(destination.getX() - delta * 100);
        }

        if (distance >= 25 && !background4.isVisible()) {
            background4.setVisible(true);
            background4.setPosition(background2.getX() + background2.getWidth(), 0);
        }

        if (background4.isVisible()) {
            background4.setX(background4.getX() - delta * 100);
            if (background4.getX() + background4.getWidth() <= 0) {
                background4.setX(background2.getX() + background2.getWidth());
            }
        }

        // 플레이어 가시성 설정
        if (!player.isVisible() && distance >= 25) {
            player.setVisible(true);
        }
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        stage.dispose();
        bgMusic.dispose();
        pointMusic.dispose();
        jumpSound.dispose();
        collisionSound.dispose();
        batch.dispose();
        font.dispose();
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void show() {
        //background music is set to play.
        bgMusic.play();
    }  }