//package com.mygdx.game;
//
//public class game_state {
//}
//
//enum GameState { pause, play, gameover }
//
//GameState gameState = GameState.pause;
//

package com.mygdx.game;

enum GameState {
    pause, play, gameover, levelup
}
