package com.mygdx.game;


import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

public class Player {
    private Texture texture;
    private Rectangle bounds;
    private float speed = 300;
    private float x = 0;
    private float y = 0;
    public float ySpeed = 1000;
    private float gravity = 600;
    private float frame = 0;
    private float width;
    private float height;

    public Player() {
        texture = new Texture("images/wallet.png");
        width = 110;
        height = 110;
        bounds = new Rectangle(100, 50, width, height);
    }

    public void render(SpriteBatch batch) {
        batch.draw(this.texture, this.x, this.y);
    }

    public void update() {
        float dt = Gdx.graphics.getDeltaTime();

        this.ySpeed -= gravity * dt;
        this.y += ySpeed * dt;

        if (this.y < 0) {
            this.y = 0;
            this.ySpeed = 0;
        }

        if (this.x <= 200) {
            this.x += 100 * dt;
        } else {
            this.x = 200;
        }

        this.frame += 20 * dt;
        if (this.frame >= 8) {
            this.frame = 0;
        }
        bounds.x = this.x;
        bounds.y = this.y;
    }

    public void draw(SpriteBatch batch) {
        batch.draw(texture, bounds.x, bounds.y, width, height);
    }

    public Rectangle getBounds() {
        return bounds;
    }

    public void dispose() {
        texture.dispose();
    }

    public void reset() {
        bounds.y = Gdx.graphics.getHeight() / 2 - height / 2;
    }

    public float getX() {
        return bounds.x;
    }

    public void setX(float x) {
        this.x = x;
        bounds.x = x;
    }

    public float getY() {
        return bounds.y;
    }

    public void setY(float y) {
        this.y = y;
        bounds.y = y;
    }

    public float getWidth() {
        return bounds.width;
    }

    public float getHeight() {
        return bounds.height;
    }

    public void moveUp() {
        this.ySpeed = 333;
    }

    public boolean collidesWithAnyWall(TiledMap map) {
        TiledMapTileLayer layer = (TiledMapTileLayer) map.getLayers().get(0);
        float tileWidth = layer.getTileWidth();
        float tileHeight = layer.getTileHeight();

        int x = (int) (bounds.x / tileWidth);
        int y = (int) (bounds.y / tileHeight);
        int x2 = (int) ((bounds.x + bounds.width) / tileWidth);
        int y2 = (int) ((bounds.y + bounds.height) / tileHeight);

        return layer.getCell(x, y) != null ||
                layer.getCell(x2, y) != null ||
                layer.getCell(x, y2) != null ||
                layer.getCell(x2, y2) != null;
    }

    public void setPosition(int i, int i1) {
    }
}