package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

class Floor {
    private Texture texture;
    private float xPos;
    private float speed;
    private float ySize;
    private GameState gameState;

    public Floor() {
        texture = new Texture("images/floor.png");
        xPos = 0;
        speed = 50;
        ySize = Gdx.graphics.getWidth() * 2 / 168 * 56;
    }

    public void update(float deltaTime) {
        if (gameState == GameState.play) {
            xPos -= speed * deltaTime;
            if (xPos <= -Gdx.graphics.getWidth()) {
                xPos = 0;
            }
        }
    }

    public void render(SpriteBatch batch) {
        batch.draw(texture, xPos, Gdx.graphics.getHeight() - ySize * 0.22f, Gdx.graphics.getWidth() * 2, ySize);
    }

    public Rectangle getBounds() {
        return new Rectangle(0, Gdx.graphics.getHeight() - ySize * 0.22f, Gdx.graphics.getWidth() * 2, ySize);
    }

    public void dispose() {
        texture.dispose();
    }

    public void setGameState(GameState gameState) {
        this.gameState = gameState;
    }
}
