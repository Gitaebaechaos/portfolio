package com.mygdx.game;

// import 문 추가
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class GameOver implements Screen {
    private MyGdxGame game;
    private SpriteBatch batch;
    private Texture gameOverImage;
    private Texture restartButtonTexture;
    private Image restartButton;
    private Stage stage;
    private BitmapFont font;

    public GameOver(MyGdxGame game, boolean b) {
        this.game = game;
        batch = new SpriteBatch();
        gameOverImage = new Texture(Gdx.files.internal("images/gameover.png"));
        restartButtonTexture = new Texture(Gdx.files.internal("images/restartButton.png"));

        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        font = new BitmapFont();
        font.getData().setScale(5);

        restartButton = new Image(restartButtonTexture);
        restartButton.setSize(400, 200); // 버튼 크기 설정
        restartButton.setPosition(
                Gdx.graphics.getWidth() / 2f - restartButton.getWidth() / 2f,
                Gdx.graphics.getHeight() / 2f - restartButton.getHeight() / 2f - 100
        );
        restartButton.addListener(new ClickListener() {
            @Override
            public void clicked(com.badlogic.gdx.scenes.scene2d.InputEvent event, float x, float y) {
                game.setScreen(new MainGameScreen(game));
                dispose();
            }
        });

        stage.addActor(restartButton);
    }

    @Override
    public void show() {
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);

        batch.begin();
        batch.draw(gameOverImage, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        batch.end();

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void dispose() {
        batch.dispose();
        gameOverImage.dispose();
        restartButtonTexture.dispose();
        stage.dispose();
        font.dispose();
    }
}