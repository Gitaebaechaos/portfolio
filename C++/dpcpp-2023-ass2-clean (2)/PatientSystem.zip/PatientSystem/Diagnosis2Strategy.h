#pragma once
#include "Strategy.h"
#include "PatientAlertLevels.h"

class diagnosis2Strategy : public Strategy
{
public:
	void diagnosis2(int bp, int age, Patient* p);

private:
	AlertLevel _alertLevel;
};