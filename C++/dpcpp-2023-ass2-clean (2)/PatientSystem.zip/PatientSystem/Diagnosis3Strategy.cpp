#include "Diagnosis3Strategy.h"
#include "Observer.h"
#include "Patient.h"

void diagnosis3Strategy::diagnosis3(int hr, Patient* p)
{
	Observer o;

	//Heart rate (HR) > 100 YELLOW
	if (hr > 100) {
		_alertLevel = AlertLevel::Yellow;
		p->setAlertLevel(_alertLevel);
	}
	//Heart rate(HR) > 120 ORANGE
	else if (hr > 120) {
		_alertLevel = AlertLevel::Orange;
		p->setAlertLevel(_alertLevel);
	}

	//Heart rate(HR)) > 130 RED
	else if (hr > 130) {
		_alertLevel = AlertLevel::Red;
		p->setAlertLevel(_alertLevel);
		o.patientAlert(p);
	}
}
