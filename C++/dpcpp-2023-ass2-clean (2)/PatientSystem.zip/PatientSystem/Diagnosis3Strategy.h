#pragma once
#include "Strategy.h"
#include "PatientAlertLevels.h"

class diagnosis3Strategy : public Strategy
{
public:
	void diagnosis3(int hr, Patient* p);

private:
	AlertLevel _alertLevel;
};