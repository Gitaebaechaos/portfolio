#include "Diagnosis4Strategy.h"
#include "Observer.h"
#include "Patient.h"

void diagnosis4Strategy::diagnosis4(int rr, int hr, int age, Patient* p)
{
	Observer o;

	//Respiratory rate(RR) > 30 and (Age > 40 or
	//(Age < 12 and heart rate(HR) > 100)) Yellow
	if ((rr > 30 && age > 40) || (age < 12 && hr > 100)) {
		_alertLevel = AlertLevel::Yellow;
		p->setAlertLevel(_alertLevel);
	}
	//Respiratory rate (RR) > 50 and (Age > 30 or 
	//(Age < 12 and heart rate(HR) > 100)) RED
	else if ((rr > 50 && age > 30) || (age < 12 && hr > 100)) {
		_alertLevel = AlertLevel::Red;
		p->setAlertLevel(_alertLevel);
		o.patientAlert(p);
	}
}
