#include "Composite.h"
#include "Adapter.h"
#include "PatientDatabaseLoader.h"
#include "Patient.h"

Composite::Composite() : _abstractPatientDatabaseLoader(std::make_unique<PatientDatabaseLoader>()), _adapter(std::make_unique<Adapter>())
{
}

void Composite::loadPatients(std::vector<Patient*>& patientIn)
{
	// Load the patient 
	_abstractPatientDatabaseLoader->loadPatients(_patients);
	for (Patient* p : _patients) {
		_patientLookup[p->uid()] = p;
	}
	_adapter->loadPatients(_patients);
	for (Patient* p : _patients) {
		_patientLookup[p->uid()] = p;
	}
	// Same as Adapter.cpp
	if (!_patients.empty()) {
		for (int i = 0; i < _patients.size(); i++) {
			patientIn.push_back(_patients.at(i));
		}
	}
}

void Composite::initialiseConnection()
{
}

void Composite::closeConnection()
{
}
