#pragma once
#include "Strategy.h"
#include "PatientAlertLevels.h"

class diagnosis4Strategy : public Strategy
{
public:
	void diagnosis4(int rr, int hr, int age, Patient* p);

private:
	AlertLevel _alertLevel;
};