#include "PatientFileLoader.h"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include "Patient.h"
#include "Vitals.h"

using namespace std;

std::vector<Patient*> PatientFileLoader::loadPatientFile(const std::string& file)
{
	vector<Patient*> patients{}; //id 1:1 data

	std::ifstream inFile(file);

	if (inFile.is_open()) {
		// TODO: load your file here

		std::string line;
		std::string id;
		std::string firstName;
		std::string lastName;
		std::string disease;
		std::string vital;
		std::string dateOfBirth;

		std::string bodyTemp;
		std::string bloodPres;
		std::string heartRate;
		std::string respRate;

		while (std::getline(inFile, line)) {

			std::tm dob{};
			std::stringstream stream(line);

			// Divide id, first name, last name, date of birth, disease, vital
			getline(stream, id, '|');
			getline(stream, dateOfBirth, '|');
			getline(stream, firstName, ',');
			getline(stream, lastName, '|');
			getline(stream, disease, '|');
			getline(stream, vital, '|');

			std::istringstream dobStream(dateOfBirth);
			dobStream >> std::get_time(&dob, "%d-%m-%Y");

			// Create new Patient object to add first name, last name, date of birth patient in data
			Patient* p = new Patient(lastName, firstName, dob);

			std::stringstream vitalStream(vital);
			std::stringstream diagnosisStream(disease);

			if (!disease.empty()) {
				while (std::getline(diagnosisStream, disease, ',')) {
					p->addDiagnosis(disease);
				}
			}

			if (!vital.empty()) {

				// Split the vital data from file
				while (vitalStream.good()) {
					string vitalData;
					getline(vitalStream, vitalData, ';');
					stringstream vitalStreamString(vitalData);

					// Divide body temperate, blood pressure, Heart rate, respitory rate
					while (vitalStream.good()) {
						getline(vitalStream, bodyTemp, ',');
						getline(vitalStream, bloodPres, ',');
						getline(vitalStream, heartRate, ',');
						getline(vitalStream, respRate);

						Vitals* vitals = new Vitals(stof(bodyTemp), stoi(bloodPres), stoi(heartRate), stoi(respRate));
						p->addVitals(vitals);
					}
				}
			}
			// Save the patient data
			patients.push_back(p);
		}

		inFile.close();
	}
	else {
		cout << "Error" << endl;
	}

	return patients;
}
