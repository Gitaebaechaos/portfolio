#pragma once
#include "Strategy.h"
#include "PatientAlertLevels.h"

class diagnosis1Strategy : public Strategy
{
public:
	void diagnosis1(int rr, Patient* p);

private:
	AlertLevel _alertLevel;
};