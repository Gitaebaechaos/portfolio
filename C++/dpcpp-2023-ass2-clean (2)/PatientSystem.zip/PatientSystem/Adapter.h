#pragma once
#include "AbstractPatientDatabaseLoader.h"
#include <vector>

class Adapter :
	public AbstractPatientDatabaseLoader {

public:
	virtual void loadPatients(std::vector<Patient*>& patientIn) override;
	virtual void initialiseConnection() override;
	virtual void closeConnection() override;

protected:
	std::vector<Patient*> _patients;
};