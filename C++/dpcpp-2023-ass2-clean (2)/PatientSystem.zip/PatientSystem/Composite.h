#pragma once
#include "AbstractPatientDatabaseLoader.h"
#include <map>
#include <vector>
#include <string>
#include <memory>

class Adapter;

class Composite :
	public AbstractPatientDatabaseLoader {

public: Composite();
	  virtual void loadPatients(std::vector<Patient*>& patientIn) override;
	  virtual void initialiseConnection() override;
	  virtual void closeConnection() override;

protected:
	std::vector<Patient*> _patients;
	std::map<std::string, Patient*> _patientLookup;
	std::unique_ptr<AbstractPatientDatabaseLoader> _abstractPatientDatabaseLoader;
	std::unique_ptr<Adapter> _adapter;
};