#pragma once
#include "PatientAlertLevels.h"
#include "Vitals.h"
#include "Patient.h"

class Patient;

class Strategy
{
public:
	void vitalStrategy(float bt, int bp, int hr, int rr, Patient* p);

protected:
	AlertLevel _alertLevel;
};
