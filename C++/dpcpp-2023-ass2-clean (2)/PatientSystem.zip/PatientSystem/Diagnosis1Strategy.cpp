#include "Diagnosis1Strategy.h"
#include "Observer.h"
#include "Patient.h"

void diagnosis1Strategy::diagnosis1(int rr, Patient* p)
{
	Observer o;

	//AlertLevel _alertLevel = AlertLevel::Green;

	// Respiratory rate (RR) > 50 RED
	if (rr > 50)
	{
		_alertLevel = AlertLevel::Red;
		p->setAlertLevel(_alertLevel);
		o.patientAlert(p);
	}
	//Respiratory rate(RR) > 30 ORANGE
	else if (rr > 30)
	{
		_alertLevel = AlertLevel::Orange;
		p->setAlertLevel(_alertLevel);
	}
	//Respiratory rate(RR) > 20 YELLOW
	else if (rr > 20)
	{
		_alertLevel = AlertLevel::Yellow;
		p->setAlertLevel(_alertLevel);
	}
}

