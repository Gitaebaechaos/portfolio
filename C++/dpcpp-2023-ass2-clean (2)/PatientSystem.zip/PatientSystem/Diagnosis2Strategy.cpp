#include "Diagnosis2Strategy.h"
#include "Observer.h"
#include "Patient.h"

void diagnosis2Strategy::diagnosis2(int bp, int age, Patient* p)
{
	Observer o;

	// Age < 12 and blood pressure (BP) < 30 RED
	if (age < 12 && bp < 30) {
		_alertLevel = AlertLevel::Red;
		p->setAlertLevel(_alertLevel);
		o.patientAlert(p);
	}
	//Age >= 12 and blood pressure(BP) < 50 RED
	else if (age >= 12 && bp < 50) {
		_alertLevel = AlertLevel::Red;
		p->setAlertLevel(_alertLevel);
		o.patientAlert(p);
	}
}
