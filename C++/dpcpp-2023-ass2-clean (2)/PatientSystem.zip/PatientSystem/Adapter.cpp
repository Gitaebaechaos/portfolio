#include "Adapter.h"
#include "PatientFileLoader.h"

void Adapter::loadPatients(std::vector<Patient*>& patientIn)
{
    PatientFileLoader pFL;

    // Use the new file loader interface
    std::vector<Patient*> loadedPatients = pFL.loadPatientFile("patients.txt");
    if (!loadedPatients.empty()) {
        for (Patient* patient : loadedPatients) {
            patientIn.push_back(patient);
        }
    }
}

void Adapter::initialiseConnection()
{
}

void Adapter::closeConnection()
{
}
