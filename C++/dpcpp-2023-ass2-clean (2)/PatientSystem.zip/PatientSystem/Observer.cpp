#include "Observer.h"
#include "GPNotificationSystemFacade.h"
#include "HospitalAlertSystemFacade.h"

void Observer::patientAlert(Patient* p)
{
	//new
	GPNotificationSystemFacade* gpNSF = new GPNotificationSystemFacade();
	HospitalAlertSystemFacade* hASF = new HospitalAlertSystemFacade();

	// GP
	gpNSF->sendGPNotificationForPatient(p);

	// Hospital
	hASF->sendAlertForPatient(p);

	delete gpNSF;
	delete hASF;
}