#pragma once
#include "Patient.h"
#include "PatientAlertLevels.h"

class Observer
{
public:
	void patientAlert(Patient* p);

protected:
	AlertLevel _alertLevel;
};