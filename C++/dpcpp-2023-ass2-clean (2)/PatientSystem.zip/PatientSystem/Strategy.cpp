#include "Strategy.h"
#include "Diagnosis1Strategy.h"
#include "Diagnosis2Strategy.h"
#include "Diagnosis3Strategy.h"
#include "Diagnosis4Strategy.h"

using namespace std;

void Strategy::vitalStrategy(float bt, int bp, int hr, int rr, Patient* p)
{
    Strategy* strategy = nullptr;

    // The alert levels are ranked ordered as Green, Yellow, Orange, Red, with Green being the 
    // lowest alert level.
    // Patient's disease is Bonus Eruptus
    if (p->primaryDiagnosis() == "BONUS_ERUPTUS") {
        diagnosis1Strategy bonusEruptus;
        bonusEruptus.diagnosis1(rr, p);
    }

    // Patient's disease is Amoria philebitis
    else if (p->primaryDiagnosis() == "AMORIA_PHLEBITIS") {
        diagnosis2Strategy amoriaPhilebitis;
        int age = p->age();
        amoriaPhilebitis.diagnosis2(bp, age, p);
    }

    // Patient's disease is Mad zombie disease
    else if (p->primaryDiagnosis() == "MAD_ZOMBIE_DISEASE") {
        diagnosis3Strategy madZombieDisease;
        madZombieDisease.diagnosis3(hr, p);
    }

    // Patient's disease is Three stooges syndrome
    else if (p->primaryDiagnosis() == "THREE_STOOGES_SYNDROME") {
        diagnosis4Strategy threeStoogesSyndrome;
        int age = p->age();
        threeStoogesSyndrome.diagnosis4(rr, hr, age, p);
    }

    // A patient defaults Green alert level unless their vitals raise their level.
    else {
        _alertLevel = AlertLevel::Green;
    }

}
