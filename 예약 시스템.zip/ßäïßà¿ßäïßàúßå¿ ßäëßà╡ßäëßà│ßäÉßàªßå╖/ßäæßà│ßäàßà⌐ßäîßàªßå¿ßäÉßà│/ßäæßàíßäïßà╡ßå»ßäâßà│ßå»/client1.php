<!DOCTYPE html>
<html>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<script src="https://www.w3schools.com/lib/w3.js"></script>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Amatic+SC">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Amatic SC", sans-serif}
</style>
<body>
<!-- Start Content -->

<!-- Navbar (Sits on top) -->
<div class="w3-top w3-bar w3-xlarge w3-black w3-opacity-min">
<a href="http://localhost/wwwroot/database.php" class="w3-bar-item w3-button">Bambooleaf</a>
<a href="http://localhost/wwwroot/database1.php" class="w3-bar-item w3-button">LaOeste</a>
<a href="http://localhost/wwwroot/database2.php" class="w3-bar-item w3-button">Mexikana</a>
<a href="http://localhost/wwwroot/select.php" class="w3-bar-item w3-button">Logout</a>
</div>

<!-- Header image -->
<div style="height:940px;background-image:url('images/restaurant1.jpg');background-size:cover" class="w3-display-container w3-grayscale-min">
<div class="w3-display-bottomleft">
</div>
</div>

<!-- End Content -->
</div>
</body>
</html>