작업기간 : 2022-06-27 ~ 2022-10-03
작업인원 : 3 명
작업 툴 : GitHub, xampp control panel, notepad
작품소개 : xampp control panel을 이용해서 Apache와 MySQL을 이용해서 notepad로 php코드를 작성을 하고 phpmyadmin으로 데이터를 관리하면서 레스토랑 북킹 로그인 시스템과 예약 시스템 그리고 웹페이지를 따로 만들어서 데이터를 불러들이고 그걸 웹페이지에 전달하여 보이게 했던 파일이다.