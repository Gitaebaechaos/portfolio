<!DOCTYPE html>
<html>
<head>
    <title>Clinic Feedback - Gender Selection</title>
    <style>
	
		#UniSA {
            position: absolute;
            top: 0;
            left: 0;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #dcdcde;
            margin: 0;
            padding: 0;
			align: left-side;
        }

        h1 {
            text-align: center;
            margin-top: 20px;
			color: blue;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        form {
            margin-top: 20px;
        }
		
		 .gender-text {
            text-align: center;
            font-size: 20px; /* Adjust the font size as needed */
            margin-top: 10px; /* Add a margin for spacing */
            color: #333; /* Add color to the text */
        }
		.select-text {
			text-align: center;
            font-size: 35px; /* Adjust the font size as needed */
			color: orange;
            <!-- margin-top: 10px; /* Add a margin for spacing */ -->
            <!-- color: green; /* Add color to the text */ -->
		}

        label {
            font-weight: bold;
        }

        select {
            width: 100%;
            padding: 10px;
        }

        button[type="submit"] {
            background-color: blue;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }
		img {
            max-width: 100px;
            max-height: 100px;
            display: block;
            margin: 0 auto;
			cursor: pointer; /* Add cursor pointer for better UX */
			border: 2px solid transparent; /* Add a transparent border initially */
        }
		.selected {
            border-color: #007bff; /* Change border color for selected image */
        }
		
    </style>
</head>
<body>
	<img src="https://courseseeker.edu.au/assets/images/institutions/3027.png" alt="UniSA" id="UniSA">
    <h1>Gender Selection</h1>
    <div class="container">
	<form id="genderForm" action="process_gender.php" method="post">
        <p class="select-text">Please select your gender:</p>

        <!-- Add an image for gender selection -->
		<input type="radio" id="male" name="gender" value="Male">
		<label for="male">
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/4f/Mars-male-symbol-pseudo-3D-blue.svg/1200px-Mars-male-symbol-pseudo-3D-blue.svg.png" alt="Male" id="maleImage">
		</label>
		<p class="gender-text">Male</p>
        <input type="radio" id="female" name="gender" value="Female">
		<label for="female">
		<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAK4AAAEiCAMAAABX1xnLAAAA9lBMVEX/////f5nMM2YAAAD/hJ/QNGj/gpzUNWrIMmS/X3JPHylBR0ZjEC6XJkuzs7PPNGh6PUl0dnYyBhc+Ch3Dw8P1epOdJ06AgoEtAAavVmiPJEg2HiJsGTazLVqsK1ZRKjHf39/S0tJbFC28L17jcYj19fVIEiTl5eXJycnZbILNZnvrdY2iUWF9Hz6srKybm5soChQYAABsNkGSSFcAExBMUVCioqLDYXWkUWKPkJA8QkEaIyEAAwBbXFwuMjFxOUQcAAA+ICZWV1c6EhuIQlBcKjROKTAYEBAkAA8dERMSGxo7ABMjAABHAB0yABVtbm5CFiAkKSjuagvEAAARAUlEQVR4nO2da1viSBOGhUrSOApBERgQkDMiAqOIiqfRHZ3RObn+/z/zVoIISaqTTkgr7155Pu16DeGmqK6u6q5u1tYiRQpdnVptJzUYDFKpnVq19dE0fNVSk+sXsOvq4nm40/loNqs6qa1LRPt8PCqcdXvZmGIq1mt218/vPxnU48n+ilh6P38C8O1+vYmUmqbFFoX/j3/MdgvHiHwxrH40684zoo4OYoqNM2ajVpTe+leAk8kHEte2AP4t9NxR58yK1h0BXA4/xisGL/D7PKsIoc6t3E0DXNfem7U1Afja9cU6s3Gs8A1udt4bduTPsBbi7gNcvh/wEOAwpgRjfQVuPsDN/rvAptCysYCGncsAHsufPjoXkM4uY9k58MEXyEumncC3ZiiwMcMlzgFkekT1Es6DDjBKSvYBtqTRDuEuHD9YAF6HKzlRuLUBhyHDorTsHgwl0NYAuuHTopRDuA6ddgAPy0cvDm8XfoYc0vJwL8W0prTsFwjVga9hXR6tAfwAIU7KG3Dgg1abyQevkoZBWLQ30BR7ayMNj/W6Z+uGzg6aPaOWEHupMgorQNxAT+AtMTPsFu6/2yrLHw+js54iMrVggAiF90KAFlOs8z2ke6z3k5VGIhFPoBrlSrHUNpjTZwLZJk7Jp8vTbnjSIuvoB0C7WNaZitLjr9J1VWUskSs9AuwVYl7EaN/UsrTXXn6L1cEuQKmisjmnVToiJ9sC1Qf675LxIQ8Hrm+hZLFabOfQpjTqTCpLFI/g7swdWPm6XPwduMdbJXuPhk0wjlntxJU2PK27Ait7UA1OW4ORC62mHQL04x52tQCX27DrnnkcBedtwYPLo5UDtGycCcMa0ll5G46zfANrPQjMuwEupo0dQ7vhD3Zq4Ry4eZh2FpR34hIUMIuCpJjPOoDjm3DMz+6U+2C8VSx0uM8cQTsh7rQ2GQbme7C2G4j353feE7XYHvT9+8GCgRMZKHCfju7rnzcPWd7zsk9QEaU1ZjZzqrNOIqzET6BxdvMdH6rcj6814agh4Ag6TsBMx8QhVywWk7lKOYF/eINmRTjm+a9yt932yXvzjUfbhW3PWIuoajlZ+mXLz37X+7kEm45QVoE9Di8apOiPN8WLCkib4SUHc9ZG8Q/S3TwPU7XOdDm31anuD/L/nAAclXJxhp+XleE7hxejQzzjhxfStHHxg2fcTYus/SOA61P63Vo7k0uAPzmd6WoZ9nj+CyWWAeF6c8IZZ1oWtl1pmZ78C7DlvpTUGowBNssM/eGYY5UCNNhfEFxnb3EXQJ6O4i6eoCb6aFeRZa/W8Cf8ymEA5iQlyo82i9/+FMPNc2ZfTJhcYgIzYCfCOw87Y9iuFGGd9F9tHcpqAi5EHtSCc/IZOJdVuLS6irD+qq3qGP5kOMWK8tTG4ALPAo+Z0MbFoMCfy1jlKMBqbe0GYJdn3oaOziJQvsGIDjDQ5tEaaUuwtfAUcIKQAnUWZ33v8mJAhwXlGBJc00LgqrB1TddX2rnxdqwNXg+4JD+udgA5juOiDcZL7O39A5wvs4/vl/BanqxBl/y0VxxX0OPt5RY0WnQ0U9KAb6hWPL635y/kiw/R9UnaxO9llw+H0KOs2zTjENt0ny2gQBk3y4kKagN+Lr3Je0JObspu3XhLFf5xeWmKHGhG0kHSlsVCubt2oEm536H5nugOLosl15+oT8oxLtJuLE+7tvZClty96eBmdX50aJG+gPMZ5bh6IxxajnmVO9MbMDpM+C8kgy5pXF1wUhfQFRU8MfSaRsLpnTc8tqgqAvM5coYQTZm8NSDn/eZrjqJzNwvJCfh1jNqEM05ojR8cH7wqme+rFjmpeoecI7pUJiYyn4uLjPZK+nFqJsZJzcgvRRuB07gYX0JY7H7TPjXYMC2bOiHPvM9UGMPvhMgWYBwiLXrhIfG19mZfq0pnpyeU6zYJX8BgGG7H0tZnaoybac40OBCvacGZExdnF4cv6F6Zh2+REVR5mOVVCcr1alSyoXx3xgX3iTyIWlTVNh81bPPS+ZoBmXpC0e4LGBVC76O5IGYK7WwW8PUyEYfyxCSBJVrZPgO7TIuBNbklnHc+bNiRc6oYU5+wAA7jljxLEv/aISc2SL6+OTXYqMCgpLftrpuQ0eBBzlDKLDQY6ZQjj6TcXbnbtFmXkVFlaVHzMA7z2Zuzz/aZrUUVpYpjpOkSPBd1c0+8+fFbhej0hio1E2YhZx1pOCNK6Wm9Jkog7f5xhuuMDftU2G3aA4PzWwlHZFhamKKY/UulZhaMY9YSGD+lnNa6IZBh6Q1X3bQVAykilmBW9C4Djfvub7ZSkzYnHNCfz+YLshotqcA7n9bMUGb9Wk9pXEtgIGfDkHAJVzxYKLtUW7jn4FqsS6dy74LL/ljXy0Rw2S85cYGL21iw1IkIrsUZ1PAavsRw59bVc9axRg61dYt10XWrknDJyHC2iGsbNp4vMKc0SbRksm39bnVrCbPvPU04YnV4mhwR3+35YuFlCw1k7WMtLNlnae3t+X/dJ2FjmFtSdHpR5C1Dnn7AMFcXLBp/deJak21101IhkoWwctVfwE2E2blq1SVVGzwsbjGw0o3lFWSGvLdQCONEWJWFS9YGu6VF69oC7wuRIWv3R/NXqJXwS+BXkcn2vPihwtIzsYr9tlBlWjcnJzVfM6IoMW6stYE9J5v8di2ezRdIol3bogKDNYrajUXNE/OFKuLrCFE/KUcsWJJtO24VuoT/HGeYfNwOWdbOSzXSFanQsLjULw+XXFlW7uqqGy61UGX4uyodl94gsy4aOHDJharZhpHUoUZ+r7blOdWOS66yTvfq5QYycrPUvrLsMBa5yoreMPtOpE0TG9S+pbJn3eV3uuIN5bzKw1ui0ZBTWJJxwbGyrPbtG3kToqAwSpCZDyXCXuSfKk9NaUahZmv0vLG9rkrmkMrTbLA5Vn7CEbnvo6SPrEu17I+jrL2i9n6Mrjmd94oQNKS7Eiz5TZysDfJECWJMxK/mVfvElsbSIttbFlxw5rvO2oBuxXkzryP0hSG6cc3hC2RtcEI3Ov2YxhTHQlUI4vQOxey+gIW7M4oOyY+K38w0jWTh70s8k9tjRp+e1bhkBkDv1RvtmtOu5nrYlXuNbttU7uydYM44Zuia7uPOglk2OVZZl9YJffalad9ksNftb5+W7HtTzqGiS5gotjg9jF+dO9H08twN/XGV7zD9jKGeQt7ndPBmnRtOnOU5uu/IeILhTeFu/LQ4/dzKvaO3iruyfEk/AqOD0fCUCHPJ9OaWtAzVuGZfjX4Tz7zKIeQYxgZqgAbTNa85mugK5K8sc7zX8P+yijlvWEkk92xkzz5FuKba+7zH4HBrqOx3SINtyDupoxw7uwLVEj9bGT/yDmDcQYMlwykpTnnnHbBGSzq7f1xS1w6nuR+1C2V2FEYWOeSe5FR2HT0Jhi9U+c/inUsx7VvOhbAOOeGeJcEJydGfgr5w4va0K+6xUG0Pcr+W7ix95h+w60HJYdy47p5a8WabmNkV3l5yVbp1w79DYZZMWY2b8xgvnLncfGABYKnlkX245Z6cx4dXnLjsl1cn2An3eJZ5kHWJC23yLkdZNdoViE4cm6ouZ7CNY8JBo0PthO+2+OSnL0TDJdt0HWimTt3O4ytnECh3aD3Dg8sxbJwgqAMPQnnKNd99DQOn4cV33TZ0PYNtOC519kWwce3yC//JxiVdn+DCV/pwCjByu2zkNecjjCtUIHZcD+UbQ+5fuBEtLjoTgHvXS6FwmJEndYS7Amu8M6KzN1C6xwD5qveTdsbmhXZuD4tlr6hhxumGpd/F9YoGEzh7aFzw6OYUrdQ1wKczzztndiFBHc9wO+dh16nLyfy5ie+Niz+H1MWfnVT+BVkL3ne3aHf0KSi17KeYHXrzGvf39MyLP2HjeXKa2je0kzrNXxtXm367P/O8tcXQHefcKdv2tbLBT51sNtayB+fph6P5IfFvD6NC1+PC0AXaMk1b9Jn+8RNTB7JmXg2b7fV62azx36I3O2nZXY5t9YTvvrWBR3xYWlrvincCmWW8p1+7dmBP1uVphjBjuiVjgrmqEaCOrcGTyD1UAWkL0NZpWszEAjXT1MDXnWR+pKWplPHVuL9fgtCavFLup9N6u5Dk0eIEEbTmRt67XujAyjocca/XwRgWvMZCXoEZw5e07AOUdN4xf6zVl+kCM3jvQrvCNGaa1lh049E2ljypU4PHbfeE1Rds8zvU+beq4PwQcJgt8NaLRjkQArCSTcOj2/U6+uPy68jIG6/Drsc1aN7SYiOAotulUPrfMBbiapjvlzOe97Z5WDbmeZOZ7uPiFi9eVsnA03rA66Mx1zTviHOFRdtWw6A1eVWVletYy/T8m1hTDh7QsgnXO6HU+HZ4vYs1+JtQddYoYVgTKBIsrE102e2kx0WBGMHC7EnpmHdQ6UzPtY0LHrNC+Tdm783RE3pBmXncCMXK8BLqTmPrZXrDl3FdYgZgd3SQdbus1PyFgcJXnGQ2K6rHhVDmzBvukd414z6Q4mt/A0vk0I1hN13okmtJWqx3dojuCtv9Cvdmy7l0VpJx6mUC9dl748BrJEvbSPREtoKh2v1KgnldbWk+K/FXTrPPPkD5bXibV6Xh2CNw141/J4RqOEISLiX1B7c2oG8ZNeh0JO4Xt4ugrKatS7wGfe0UbssL8VPl4CbEeHU0rbzGdkOdi8XZiYcbj4vwskYm8AK3sAZGojJrOORZV/XmZfESvLzHj3zkjes2VVfcuO7By+L9YEvxAdS5hlsTmI/rzqsasFJ6/2hVn9El4swFl8+L0wzmHvn3/XWazhYmA40kH5fm1Zlaqfu50C40tYZXOHvxcZ28xnWR6AXCewVhq0ZdLDY/JLLIa97C2b8V2yaQJepcycKZlimvbqA2kpvgeV3kB+NOeRu5vnFh6IXrZsZK4Jq8AFfXw48166s8cY1t/tqK/M6aEK68E07+FeHKVIQrUxGuTEW4MhXhylSEK1MRrkxFuDIV4cpUhCtTEa5MRbgyFeHKVIQrU/8N3OmPc5piOUm4ky3/GtO49QVlQOhJz373huHzJ//6Sl2a/n3PIqEH+d7LhoISQE7aWCzIc+788tK3HryTlN1+yR/vB+OWWN0X70fjqv54PxrXOErvg/fjcX3xrgCuH95VwPXBuxK44ryrgSvMuyK4oryrgivIuzK4Bq93P8Hq4MbZrXeH7CrhClyoHOFGuAu4AYoA+gKhAPKPu5f2L+qSw16A56Sv/OKO4Taz7VO3nN7zjG9tLx5jE7pqfQwN5lOclk2o+30Qw6lhzit2M/yYc4ibK15DbIX/S7lcLfIKXmS/4ZOXh6sjr78PbuUVvXffp3257cZsOV7hnwnwx8vvjl6OV/xXDXz5g0szN1vGf338CIMf+7r1ni/D6+c3I3zY1w13GX/w9RMX4ryuuEvw+vtFDmF/cMddgtffD4iI2tcDN7D/Vn75O2+H9p2v1/PFOwD2tjdh2lfkSYsPZZvg93jgBmyKqO21lYK8GaEnLarkG3ft+WJDQDeeOz/4BYg8yKYLOSdB/hsbVRFuKIpwZSrClakIV6YiXJmKcGUqwpWpCFemIlyZinBlKsKVqQhXpiJcmYpwZSrClakIV6YiXJn6v8ONZR1aXdwBkJr/Tvlq4a6NoZ9zqL2w6blauOb+pm6Vqmbm9l0xXHK/G3lnf1w1XA/elcN15109XFfeFcR1411FXLJfY8q7krh83tXE5foDW01crn1lnWRdVoR9dbUNoj/l9e7agEo8YVU8nlnuFxBlaoPOzz4ai6sdSh9+FWik/5r+B1q+8XiXlF5HAAAAAElFTkSuQmCC" alt="Female" id="femaleImage">
		</label>
		<p class="gender-text">Female</p>
        <input type="radio" id="other" name="gender" value="Other">
		<label for="other">
		<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTM0vgj9guickwDFvH0F3zjBsH8VYi0onXtyQ&usqp=CAU.png" alt="Other" id="otherImage">
		</label>
		<p class="gender-text">Other</p>

        <!-- Hidden input to store the selected gender -->
        <input type="hidden" id="selectedGender" name="gender" value="">

        <!-- <form id="genderForm"> -->
            <!-- Remove the select element for gender -->
            <!-- <select id="gender" name="gender" required> </select> -->

            <button type="submit">Next</button>
        </form>
    </div>

    <script>
        // Add click event listeners to the gender images
        document.getElementById('maleImage').addEventListener('click', function() {
            selectGender('male');
        });

        document.getElementById('femaleImage').addEventListener('click', function() {
            selectGender('female');
        });

        document.getElementById('otherImage').addEventListener('click', function() {
            selectGender('other');
        });

        // Function to update the selected gender and highlight the selected image
        function selectGender(gender) {
            // Update the hidden input with the selected gender
            document.getElementById('selectedGender').value = gender;

            // Remove the "selected" class from all images
            var allImages = document.querySelectorAll('img');
            for (var i = 0; i < allImages.length; i++) {
                allImages[i].classList.remove('selected');
            }

            // Add the "selected" class to the clicked image for visual indication
            document.getElementById(gender + 'Image').classList.add('selected');
        }

        // document.getElementById('genderForm').addEventListener('submit', function(event) {
            // event.preventDefault();

            // Retrieve the selected gender from the hidden input
            // var selectedGender = document.getElementById('selectedGender').value;
		// if (selectedGender) {
            // // Redirect to the feedback page with the selected gender as a query parameter
            // window.location.href = 'feedback.php?gender=' + selectedGender;
		 // } else {
                // // If no gender is selected, display an alert to the user
                // alert('Please select your gender before proceeding.');
            // }
		// });
    </script>
</body>
</html>
