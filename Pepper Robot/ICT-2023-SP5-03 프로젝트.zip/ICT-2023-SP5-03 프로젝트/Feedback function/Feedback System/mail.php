<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve data from the form
    $name = $_POST['name'];
    $email = $_POST['email'];
    $service = $_POST['service'];
    $rating = $_POST['rating'];
    $comments = $_POST['comments'];

    // Connect to the database (update these credentials)
    $dbHost = 'localhost'; // Replace with your database host
    $dbUser = 'root';      // Replace with your database username
    $dbPassword = '';      // Replace with your database password
    $dbName = 'feedback'; // Replace with your database name

    $conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);

    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    // Prepare and execute the SQL statement to insert data
    $sql = "INSERT INTO user_feedback (name, email, service, rating, comments) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssis', $name, $email, $service, $rating, $comments);

    if ($stmt->execute()) {
        // Send a greeting email to the user
        $email_subject = "Thank you for your feedback";
        $email_body = "Hello $name,\n\n";
        $email_body .= "Thank you for providing feedback on our services. We appreciate your input and will use it to improve our service quality.\n";
        $email_body .= "Your feedback:\n";
        $email_body .= "Service: $service\n";
        $email_body .= "Rating: $rating\n";
        $email_body .= "Comments: $comments\n\n";
        $email_body .= "Best regards,\nYour Company Name";

        // Replace the following details with your email server settings
        $mail_to = $email; // Recipient's email address
        $mail_headers = "From: polsgwnb@naver.com"; // Sender's email address
        $mail_success = mail($mail_to, $email_subject, $email_body, $mail_headers);

        if ($mail_success) {
            header('Location: success.php');
            exit; // Make sure to exit to stop further script execution
        } else {
            echo 'Error: Email not sent.';
        }
    } else {
        echo 'Error: ' . $stmt->error;
    }

    // Close the statement and the database connection
    $stmt->close();
    $conn->close();
} else {
    echo 'Invalid request method.';
}
?>