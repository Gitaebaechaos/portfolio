<?php
$connect = mysqli_connect("localhost", "root", "", "feedback");
$sql = "SELECT * FROM user_feedback";  
$result = mysqli_query($connect, $sql);
$connect1 = mysqli_connect("localhost", "root", "", "gender");
$sql1 = "SELECT * FROM user_gender";  
$result1 = mysqli_query($connect1, $sql1);
?>
<html>  
 <head>  
  <title>Export MySQL data to Excel in PHP</title>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
 </head>  
 <body>  
  <div class="container">  
   <br />  
   <br />  
   <br />  
   <div class="table-responsive">  
    <h2 align="center">Export client feedback data to Excel</h2><br /> 
    <table class="table table-bordered">
     <tr>   
                         <th>Name</th>  
                         <th>Email</th>  
       <th>Service</th>
       <th>Rating</th>
	   <th>Comments</th>
                    </tr>
     <?php
	 // while($row = mysqli_fetch_array($result1))  
     // {  
        // echo '  
       // <tr>  
         // <td>'.$row["gender"].'</td>  
       // </tr>  
        // ';  
     // }
     while($row = mysqli_fetch_array($result))  
     {  
        echo '  
       <tr>  
         <td>'.$row["name"].'</td>  
         <td>'.$row["email"].'</td>  
         <td>'.$row["service"].'</td>  
         <td>'.$row["rating"].'</td>
		 <td>'.$row["comments"].'</td>
       </tr>  
        ';  
     }
     ?>
    </table>
    <br />
    <form method="post" action="export.php">
     <input type="submit" name="export" class="btn btn-success" value="Export" />
    </form>
   </div>  
  </div>  
 </body>  
</html>
