<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the selected gender from the form
    $selectedGender = $_POST['gender'];

    // Validate the selected gender (you can add more validation if needed)

    // Database connection parameters
    $dbHost = 'localhost'; // Replace with your database host
    $dbUser = 'root';      // Replace with your database username
    $dbPassword = '';      // Replace with your database password
    $dbName = 'gender'; // Replace with your database name

    // Create a database connection
    $conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);

    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    // SQL query to insert the selected gender into the database
    $sql = "INSERT INTO user_gender (gender) VALUES (?)";

    // Prepare and execute the SQL statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $selectedGender);

    if ($stmt->execute()) {
        // Redirect to the feedback page after successful gender selection
        header('Location: feedback.php');
        exit; // Make sure to exit to stop further script execution
    } else {
        echo 'Error: ' . $stmt->error;
    }

    // Close the statement and the database connection
    $stmt->close();
    $conn->close();
} else {
    echo 'Invalid request method.';
}
?>
