<!DOCTYPE html>
<html>
<head>
    <title>Success Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        #successMessage {
            background-color: #4CAF50;
            color: #fff;
            padding: 20px;
            border-radius: 10px;
            margin: 50px auto;
            width: 70%;
            max-width: 500px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        #successMessage p {
            font-size: 24px;
        }

        button {
            background-color: #008CBA;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            margin-top: 20px;
        }

        button:hover {
            background-color: #005F80;
        }
    </style>
</head>
<body>
<form id="feedbackForm" method="post">
    <div id="successMessage">
        <p>Thank you for your feedback! Your response has been submitted successfully.</p>
        <button type="button" onclick="goToGenderPage()">Back</button>
	</div>
</form>
<script>
    function goToGenderPage() {
        window.location.href = "http://192.168.0.190:5501/index.html";
    }
</script>
</body>
</html>
