<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'C:/xampp/PHPMailer-master/src/PHPMailer.php';
require 'C:/xampp/PHPMailer-master/src/Exception.php';
require 'C:/xampp/PHPMailer-master/src/SMTP.php';
require 'C:/xampp/phpMyAdmin/vendor/autoload.php';  // Adjust the path to autoload.php according to your project structure

echo "Received data:\n";
var_dump($_POST);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve data from the form
    $name = $_POST['name'];
    $email = $_POST['email'];
    $service = isset($_POST['service']) ? $_POST['service'] : null;
    $selectedRating = $_POST['rating']; // Corrected rating value handling
    $comments = $_POST['comments'];

    // Connect to the database (update these credentials)
    $dbHost = 'localhost'; // Replace with your database host
    $dbUser = 'root';      // Replace with your database username
    $dbPassword = '';      // Replace with your database password
    $dbName = 'feedback'; // Replace with your database name

    $conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);

    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    // Check if both service and rating are provided
    if ($service !== null) {
        // Prepare and execute the SQL statement to insert data
        $sql = "INSERT INTO user_feedback (name, email, service, rating, comments) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param('sssss', $name, $email, $service, $selectedRating, $comments);

            if ($stmt->execute()) {
                // Use PHPMailer for sending emails
                $mail = new PHPMailer(true);

                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'zhenghaozhuo@gmail.com'; // Your Gmail email address
                    $mail->Password = 'pdki qsqq fxfn incs'; // Your Gmail password
                    $mail->SMTPSecure = 'tls';
                    $mail->Port = 587;

                    $mail->setFrom('polsgwnb@naver.com');
                    $mail->addAddress($email);
                    $mail->Subject = 'Feedback Automatic Mail';
                    $mail->isHTML(true); // Set email format to HTML

                    // HTML content with inline CSS
                    $mail->Body = "
                        <div style='font-family: Arial, sans-serif; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f7f7f7;'>
                            <h1 style='color: #008080;'>Thank You for Your Feedback!</h1>
                            <div>
                                <p style='font-weight: bold; color: #008080;'>Dear $name,</p>
                                <p>We hope this email finds you well. Thank you so much for taking the time to provide us with your valuable feedback. We genuinely appreciate your insights, as they play a crucial role in helping us enhance our services.</p>

                                <p>Your feedback:</p>
                                <ul>
                                    <li>Name: $name</li>
                                    <li>Email: $email</li>
                                    <li>Service: $service</li>
                                    <li>Rating: $selectedRating</li>
                                    <li>Comments: $comments</li>
                                </ul>
                            </div>

                            <p>We want you to know that your opinions matter to us, and we are committed to addressing any concerns or suggestions you've shared. Our team is constantly working to improve, and your input guides us in the right direction.</p>

                            <p>If you have any further thoughts or if there is anything specific you would like to discuss, please feel free to reach out to us. Your satisfaction is our top priority.</p>

                            <p>Once again, thank you for choosing us and for helping us strive for excellence. We look forward to serving you again in the future.</p>

                            <div style='margin-top: 20px; font-size: 14px;'>
                                <p>Best regards,</p>
                                <p>[UniSA/Health Clinic]</p>
                                <p>[0413 730 534]</p>
                            </div>
                        </div>
                    ";

                    $mail->send();

                    // Redirect to success page after successful email sending
                    header('Location: success.php');
                    exit;
                } catch (Exception $e) {
                    echo 'Error sending feedback email: ' . $mail->ErrorInfo;
                }
            } else {
                echo 'Error: ' . $stmt->error;
            }

            // Close the statement
            $stmt->close();
        } else {
            echo 'Error: Statement preparation failed.';
        }
    } else {
        echo 'Error: Invalid service provided.';
    }

    // Close the database connection
    $conn->close();
} else {
    echo 'Invalid request method.';
}
?>
