<!DOCTYPE html>
<html>
<head>
    <title>Clinic Feedback - Feedback Form</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>

		#UniSA {
            position: absolute;
            top: 0;
            left: 0;
        }
	
        body {
            font-family: Arial, sans-serif;
            background-color: #dcdcde;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            margin-top: 20px;
			color: blue;
        }
		
		.custom-dropdown {
            width: 250px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        form {
            margin-top: 20px;
        }

        label {
            <!-- font-weight: bold; -->
			font-size: 20px;
			color: black;
        }

        .rating {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .rating input[type="radio"] {
            display: none;
        }

        .rating label {
            cursor: pointer;
            font-size: 24px;
        }

        .rating label:before {
            content: "\2605"; /* Unicode star character */
            color: #ddd;
        }

        .rating input[type="radio"]:checked ~ label:before {
            color: #f0c040; /* Color for selected stars */
        }

        #comments {
            width: 100%;
            height: 100px;
        }

        button[type="submit"] {
            background-color: blue;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }
		button[type="button"] {
            background-color: blue;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }
		select.dropdown {
		  border: 1px solid blue;
		  <!-- background-color: #007bff; -->
		  color: #fff;
		}
		.dropdown {
			width: 200px;
			padding: 10px;
			border: 1px solid #ccc;
			background-color: #f5f5f5;
			border-radius: 5px;
			color: #333;
			font-weight: bold;
		  }

		  /* Style the options */
		  .dropdown option {
			background-color: #fff;
			font-weight: bold;
			color: #333;
		  }

		  /* Style the options on hover */
		  .dropdown option:checked, option:hover {
			background-color: #007bff;
			color: white;
		  }
		  <!-- select option { -->
			<!-- background-color: green; -->
			<!-- font-weight: bold; -->
			<!-- color: red; -->
		<!-- } -->
		
        #successMessage {
            text-align: center;
            margin-top: 20px;
            display: none;
        }
		img {
            max-width: 85px;
            max-height: 100px;
            display: inline-block;
            margin: 0 10px;
            cursor: pointer; /* Add cursor pointer for better UX */
            border: 2px solid transparent; /* Add a transparent border initially */
        }

        .gender-text {
            text-align: center;
            font-size: 20px; /* Adjust the font size as needed */
            margin-top: 0 10px; /* Add a margin for spacing */
            color: #333; /* Add color to the text */
        }

        .selected {
			border: 2px solid blue; /* Blue border for selected images */
		}

        .feedback-rating {
            text-align: center;
            font-size: 20px; /* Adjust the font size as needed */
            margin-top: 0 10px; /* Add a margin for spacing */
            color: orange; /* Add color to the text */
        }

        .feedback-rating img {
            cursor: pointer; /* Add cursor pointer for better UX */
			margin: 0 1px;
        }
		.select-text {
			text-align: center;
            font-size: 25px; /* Adjust the font size as needed */
			color: orange;
		}
		.feedback-text {
            font-size: 10px; /* Adjust the font size as needed */
            margin-top: 0; /* Add a margin for spacing */
            color: #333; /* Add color to the text */
        }
    </style>
</head>
<body>
	<img src="https://courseseeker.edu.au/assets/images/institutions/3027.png" alt="UniSA" id="UniSA">
    <h1>Feedback Form</h1>
    <div class="container">
		<form id="feedbackForm" action="process_feedback.php" method="post">
			<p class="select-text">Please share your thoughts and experience</p>
            <label for="name">Name (Optional) : </label>
            <input type="text" id="name" name="name">
			<br><br>

            <label for="email">Email (Optional) : </label>
            <input type="email" id="email" name="email">
			<br><br>
			
			<div class="form-group">
				<label for="service">Select a Service (Required) : </label>
				<select id="serviceDropdown" name="service" class="dropdown" required>
					<option value="" disabled>Select a Service</option>
					<option value="Dietetics">Dietetics</option>
					<option value="Exercise Physiology">Exercise Physiology</option>
					<option value="General Practitioners">General Practitioners</option>
					<option value="High Performance">High Performance</option>
					<option value="Legal Advice Clinic">Legal Advice Clinic</option>
					<option value="Mammography">Mammography</option>
					<option value="Marketing Clinic">Marketing Clinic</option>
					<option value="Midwifery">Midwifery</option>
					<option value="Occupational Therapy">Occupational Therapy</option>
					<option value="Physiotherapy">Physiotherapy</option>
					<option value="Podiatry">Podiatry</option>
					<option value="Psychology Clinic">Psychology Clinic</option>
					<option value="Speech Pathology">Speech Pathology</option>
					<option value="Tax Clinic">Tax Clinic</option>
				</select>
			</div>
			<br><br><br>
			
			<!-- Add an image for feedback smiley faces -->
			<label for="rating">Overall Rating (Required) : </label>
			<br><br><br>
			<div class="feedback-rating" id="rating">
			<input type="radio" name="rating" value="Very Good" id="very good" required>
			<label for="very good">
				<img src="/img/verygood.png" alt="Very Happy Faces" id="VeryHappyImage">
			</label>
			<input type="radio" name="rating" value="Good" id="good" required>
			<label for="good">
				<img src="/img/good.png" alt="Happy Faces" id="HappyImage">
			</label>
			<input type="radio" name="rating" value="Not Bad" id="not bad" required>
			<label for="not bad">
				<img src="/img/notbad.png" alt="Average Faces" id="AverageImage">
			</label>
			<input type="radio" name="rating" value="Bad" id="bad" required>
			<label for="bad">
				<img src="/img/bad.png" alt="Mad Faces" id="MadImage">
			</label>
			<input type="radio" name="rating" value="Very Bad" id="very bad" required>
			<label for="very bad">
				<img src="/img/verybad.png" alt="Very Mad Faces" id="VeryMadImage">
			</label>
	
			</div><br>
		
			<p class="feedback-rating">Please rate your experience</p>
			

            <label for="comments">Comments (Optional) : </label><br>
            <textarea id="comments" name="comments" ></textarea><br><br>
			
            <button type="submit">Submit Feedback</button>
			<button type="button" id="backButton" onclick="history.back()">Back</button>
		</form>
    </div>

<script>
  const images = document.querySelectorAll('.feedback-rating img');

  images.forEach(image => {
    image.addEventListener('click', () => {
      // Remove the 'selected' class from all images
      images.forEach(img => img.classList.remove('selected'));

      // Add the 'selected' class to the clicked image
      image.classList.add('selected');
    });
  });
</script>

</body>
</html>
