<?php  
//export.php  
$connect = mysqli_connect("localhost", "root", "", "feedback");
$connect1 = mysqli_connect("localhost", "root", "", "gender");
$output = '';
if(isset($_POST["export"]))
{
 $query = "SELECT * FROM user_feedback";
 $query1 = "SELECT * FROM user_gender";
 $result = mysqli_query($connect, $query);
 $result1 = mysqli_query($connect1, $query1);
 
 // if(mysqli_num_rows($result1) > 0)
 // {
  // $output .= '
   // <table class="table" bordered="1">  
                    // <tr>  
                         // <th>Gender</th>
                    // </tr>
  // ';
 
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>    
                         <th>Name</th>  
                         <th>Email</th>  
       <th>Service</th>
       <th>Rating</th>
	   <th>Comments</th>
                    </tr>
  ';
  // while($row = mysqli_fetch_array($result1))
  // {
   // $output .= '
    // <tr>  
                         // <td>'.$row["gender"].'</td>
                    // </tr>
   // ';
  // }
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
                         <td>'.$row["name"].'</td>  
                         <td>'.$row["email"].'</td>  
       <td>'.$row["service"].'</td>  
       <td>'.$row["rating"].'</td>
	   <td>'.$row["comments"].'</td>
                    </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }
}
?>