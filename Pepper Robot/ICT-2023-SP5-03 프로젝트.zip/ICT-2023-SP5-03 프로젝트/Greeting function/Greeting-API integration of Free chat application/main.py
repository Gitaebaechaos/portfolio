import json

import requests
import uvicorn as uvicorn
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.asr.v20190614 import asr_client, models
import base64

# Set up configuration and initializes a client for using Tencent Cloud's ASR service
#Create an instance of Tencent Cloud credentials. This credential instance is needed for authenticating and authorizing access。 Note 1
cred = credential.Credential("AKIDCfusa2MFAra8E2iqqa3MSSFm47uQedAQ", "lGdiW5RWM7ch02oNTKAk5C3e4Whla9Va")

# create an instance of the HttpProfile() class. Note2.2
httpProfile = HttpProfile()

# specify the domain to access Note2.1
httpProfile.endpoint = "asr.tencentcloudapi.com"

# create an instance of the ClientProfile() class. define the httpProfile and signMethod. Note3
clientProfile = ClientProfile()
clientProfile.httpProfile = httpProfile
clientProfile.signMethod = "TC3-HMAC-SHA256"
client = asr_client.AsrClient(cred, "ap-shanghai", clientProfile)


# create an instance of SentenceRecognitionRequest class
req = models.SentenceRecognitionRequest()


from fastapi import FastAPI  # import
app=FastAPI()                  # create FastAPI  instance

#define a route for handling HTTP POST requests to the path "/api/submit" in the FastAPI application
@app.post("/api/submit")  # decorator
#decorated function will be called when a POST request is made to the "/api/submit" path.
async def submit_data(data:dict):
    #
    try:
        params = {"ProjectId": 0, "SubServiceType": 2, "EngSerViceType": "16k_en", "SourceType": 1, "Url": "",
                  "VoiceFormat": "wav", "Data": data["name"]}

        #update the attributes based on the params dictionary

        # what really doing is specify every argument needed for the request to process ASR, Note4
        req._deserialize(params)

        # audio to text Note5
        # req is a sentenceRequest instance contains audio data and related arguments
        # client.SentenceRecognition(req) is calling for the Tencent ASR services
        # to json string is converting the response to  json string data , and then json.load will parse it to Python Dictionary data
        # Finally the response we get from ASR service is in Python dictionary data type and assigned to resp variable
        resp = json.loads(client.SentenceRecognition(req).to_json_string())

        #Now I can use the "Result" key to access to and print the response in the console, because it is a python dictionary
        print("Question asked to pepper: "+resp["Result"])

        # get a response from brainshop ai chatbot
        sp = requests.get("http://api.brainshop.ai/get?bid=178349&key=hLmPIX6sWJ3HXoKY&uid=12&msg=" + resp["Result"])

        #http://api.brainshop.ai/get?bid=178349&key=hLmPIX6sWJ3HXoKY&uid=12&msg="

        #sp.text is the response returned from brainshop, and then use json load to convert it in python dictionary.
        # cnt stand for content key of the brainshop response.
        print("Answer from Pepper: "+json.loads(sp.text)["cnt"])
    except TencentCloudSDKException as err:
        print(err)

    return {"message":json.loads(sp.text)["cnt"]} # return a Python Dictionary data



if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8060)

    # run the FastAPI uvicon server