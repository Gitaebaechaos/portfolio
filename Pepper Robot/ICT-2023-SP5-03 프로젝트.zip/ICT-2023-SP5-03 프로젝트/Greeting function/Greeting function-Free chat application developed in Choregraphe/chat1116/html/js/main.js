//防止图片移动的方法
// document.ontouchmove=function(e){
// 	e.preventDefault();
// };
$(function(){
	// var herf=document.getElementById("qq").href;window.open(href);
	//找到css样式为container的模块下的css样式为bt的子模块进行遍历
	$(".container").children(".bt").each(function(){
		//遍历样式为li的模块
        $(this).children("li").each(function(){
            this.addEventListener('touchstart', function(event,href) {
                // event.preventDefault();
				//将该模块下的p标签下的文字作为调用send方法的参数
                send($(this).children("p").html());

				// turn(href)
            }, false);
        });
    });
    var back=document.getElementById("fanhui");
    back.addEventListener('touchstart', function(event){
    	return_index();
    },false)
});
function send(oid){
	//oid为传递过来的文字，作为执行事件的value值
	$.raiseALMemoryEvent("test/speak",oid);
}
   function return_index1(){
   	$.raiseALMemoryEvent("start/dance");
   	window.location.href='./index.html'
}

function return_index(){
    // alert("666")
   	$.raiseALMemoryEvent("stop/say");
   	window.location.href='../index.html'
}



