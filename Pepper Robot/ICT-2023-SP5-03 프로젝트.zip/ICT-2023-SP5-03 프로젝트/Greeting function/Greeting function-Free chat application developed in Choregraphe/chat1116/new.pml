<?xml version="1.0" encoding="UTF-8" ?>
<Package name="new" format_version="4">
    <Manifest src="manifest.xml" />
    <BehaviorDescriptions>
        <BehaviorDescription name="behavior" src="behavior_1" xar="behavior.xar" />
    </BehaviorDescriptions>
    <Dialogs>
        <Dialog name="ExampleDialog" src="behavior_1/ExampleDialog/ExampleDialog.dlg" />
    </Dialogs>
    <Resources>
        <File name="__init__" src="lib/requests/__init__.py" />
        <File name="__version__" src="lib/requests/__version__.py" />
        <File name="_internal_utils" src="lib/requests/_internal_utils.py" />
        <File name="adapters" src="lib/requests/adapters.py" />
        <File name="api" src="lib/requests/api.py" />
        <File name="auth" src="lib/requests/auth.py" />
        <File name="certs" src="lib/requests/certs.py" />
        <File name="compat" src="lib/requests/compat.py" />
        <File name="cookies" src="lib/requests/cookies.py" />
        <File name="exceptions" src="lib/requests/exceptions.py" />
        <File name="help" src="lib/requests/help.py" />
        <File name="hooks" src="lib/requests/hooks.py" />
        <File name="models" src="lib/requests/models.py" />
        <File name="packages" src="lib/requests/packages.py" />
        <File name="sessions" src="lib/requests/sessions.py" />
        <File name="status_codes" src="lib/requests/status_codes.py" />
        <File name="structures" src="lib/requests/structures.py" />
        <File name="utils" src="lib/requests/utils.py" />
        <File name="camera1" src="behavior_1/camera1.ogg" />
        <File name="swiftswords_ext" src="behavior_1/swiftswords_ext.mp3" />
        <File name="taichimove" src="behavior_1/taichimove.pmt" />
        <File name="robotutils" src="html/js/robotutils.js" />
        <File name="Appointments" src="html/Appointments.html" />
        <File name="about" src="html/about.html" />
        <File name="style-starter" src="html/assets/css/style-starter.css" />
        <File name="FontAwesome" src="html/assets/fonts/FontAwesome.otf" />
        <File name="fontawesome-webfont" src="html/assets/fonts/fontawesome-webfont.eot" />
        <File name="fontawesome-webfont" src="html/assets/fonts/fontawesome-webfont.svg" />
        <File name="fontawesome-webfont" src="html/assets/fonts/fontawesome-webfont.ttf" />
        <File name="fontawesome-webfont" src="html/assets/fonts/fontawesome-webfont.woff" />
        <File name="fontawesome-webfont" src="html/assets/fonts/fontawesome-webfont.woff2" />
        <File name="jquery-1.9.1.min" src="html/assets/js/jquery-1.9.1.min.js" />
        <File name="owl.carousel" src="html/assets/js/owl.carousel.js" />
        <File name="index" src="html/index.html" />
        <File name="jquery-2.2.2.min" src="html/js/jquery-2.2.2.min.js" />
        <File name="jquery.qimhelpers" src="html/js/jquery.qimhelpers.js" />
        <File name="main" src="html/js/main.js" />
        <File name="services" src="html/services.html" />
        <File name="team" src="html/team.html" />
        <File name="Hi Pepper to Trigger" src="Hi Pepper to Trigger.txt" />
    </Resources>
    <Topics>
        <Topic name="ExampleDialog_enu" src="behavior_1/ExampleDialog/ExampleDialog_enu.top" topicName="ExampleDialog" language="en_US" />
        <Topic name="ExampleDialog_mnc" src="behavior_1/ExampleDialog/ExampleDialog_mnc.top" topicName="ExampleDialog" language="zh_CN" />
    </Topics>
    <IgnoredPaths />
    <Translations auto-fill="en_US">
        <Translation name="translation_en_US" src="translations/translation_en_US.ts" language="en_US" />
        <Translation name="translation_zh_CN" src="translations/translation_zh_CN.ts" language="zh_CN" />
    </Translations>
</Package>
