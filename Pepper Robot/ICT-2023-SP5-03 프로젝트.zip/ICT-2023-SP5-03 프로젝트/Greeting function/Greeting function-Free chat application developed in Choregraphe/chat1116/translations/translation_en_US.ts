<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>hi i'm pepper can i help you?</source>
            <comment>Text</comment>
            <translation type="obsolete">hi i'm pepper can i help you?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>你好</source>
            <comment>Text</comment>
            <translation type="obsolete">你好</translation>
        </message>
        <message>
            <source>启动对话程序成功,请和我说话吧</source>
            <comment>Text</comment>
            <translation type="obsolete">启动对话程序成功,请和我说话吧</translation>
        </message>
    </context>
</TS>
