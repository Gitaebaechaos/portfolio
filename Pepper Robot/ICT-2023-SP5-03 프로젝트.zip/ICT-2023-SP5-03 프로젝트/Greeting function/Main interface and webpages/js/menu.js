const services = document.getElementById("services");
const navigate = document.getElementById("navigate");
const feedback = document.getElementById("feedback");
const survey = document.getElementById("survey");
const aboutus = document.getElementById("aboutus");


services.addEventListener("click", function () {
  console.log("clicked services");

   window.location.href = "services.html";
  });
  
navigate.addEventListener("click", function () {
  console.log("clicked navigate");
  window.location.href = "navigate.html";
});

feedback.addEventListener("click", function () {
  console.log("clicked feedback");
  window.location.href = "http://192.168.0.190:8080/Feedback%20System/feedback.php";
});

survey.addEventListener("click", function () {
 
  window.location.href = "http://192.168.0.190/Survey/3";
});

aboutus.addEventListener("click", function () {
  console.log("clicked aboutus");
  window.location.href = "home.html";
});


